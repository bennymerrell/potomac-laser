/* Standalone tweaks panel — deliberately does NOT register as the host's edit
   mode, so the editor's Edit button stays free for in-place text editing.
   Values persist in localStorage. Usage:
     initTweaks({ key, defaults, apply, schema })                              */
(function () {
  var CSS = `
.twk-launch{position:fixed;right:16px;bottom:16px;z-index:2147483000;display:flex;align-items:center;gap:8px;
  font:700 11px/1 Inter,system-ui,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#fff;
  background:#15253D;border:1px solid rgba(255,255,255,.14);border-radius:999px;padding:11px 16px;cursor:pointer;
  box-shadow:0 10px 28px rgba(15,42,68,.28)}
.twk-launch:hover{background:#1D3557}
.twk-launch i{width:7px;height:7px;border-radius:50%;background:#F5821F;display:block}
.twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483001;width:288px;max-height:78vh;overflow:auto;
  background:#fff;border:1px solid #E5E7EB;border-radius:14px;box-shadow:0 22px 58px rgba(15,42,68,.22);
  font-family:Inter,system-ui,sans-serif;color:#15253D}
.twk-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:14px 16px;
  border-bottom:1px solid #E5E7EB;position:sticky;top:0;background:#fff;border-radius:14px 14px 0 0}
.twk-head b{font-size:11px;font-weight:800;letter-spacing:.18em;text-transform:uppercase;color:#F5821F}
.twk-x{width:26px;height:26px;border-radius:50%;border:0;background:#F3F4F6;color:#6B7280;cursor:pointer;font-size:15px;line-height:1}
.twk-x:hover{background:#E5E7EB}
.twk-body{padding:6px 16px 16px}
.twk-sec{font-size:10px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:#9AA3B2;margin:16px 0 8px}
.twk-row{margin:10px 0}
.twk-lab{display:flex;align-items:center;justify-content:space-between;font-size:12px;font-weight:600;color:#4B5563;margin-bottom:6px}
.twk-lab span{font-weight:700;color:#15253D}
.twk-seg{display:flex;gap:6px;flex-wrap:wrap}
.twk-seg button{flex:1 1 auto;min-width:64px;padding:7px 10px;border-radius:999px;border:1px solid #E5E7EB;background:#fff;
  font:700 11px/1.2 Inter,system-ui,sans-serif;color:#4B5563;cursor:pointer}
.twk-seg button:hover{border-color:#F1B07A}
.twk-seg button.on{background:#FEF0E3;border-color:#F5821F;color:#D96E10}
.twk-sw{width:40px;height:22px;border-radius:999px;border:0;background:#D8DDE5;position:relative;cursor:pointer;flex:0 0 auto}
.twk-sw::after{content:"";position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:left .16s}
.twk-sw.on{background:#F5821F}
.twk-sw.on::after{left:21px}
.twk-range{width:100%;accent-color:#F5821F}
.twk-sel{width:100%;padding:8px 10px;border:1px solid #E5E7EB;border-radius:10px;font:600 12px Inter,system-ui,sans-serif;color:#15253D;background:#fff}
.twk-reset{margin-top:16px;width:100%;padding:9px;border-radius:999px;border:1px solid #E5E7EB;background:#fff;
  font:700 10px/1 Inter,system-ui,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:#6B7280;cursor:pointer}
.twk-reset:hover{border-color:#15253D;color:#15253D}
@media print{.twk-launch,.twk-panel{display:none !important}}`;

  window.initTweaks = function (cfg) {
    var store = "tweaks:" + cfg.key;
    var vals = Object.assign({}, cfg.defaults);
    try { Object.assign(vals, JSON.parse(localStorage.getItem(store) || "{}")); } catch (e) {}

    var style = document.createElement("style");
    style.textContent = CSS;
    document.head.appendChild(style);

    var launch = document.createElement("button");
    launch.className = "twk-launch";
    launch.innerHTML = '<i></i>Tweaks';
    document.body.appendChild(launch);

    var panel = document.createElement("div");
    panel.className = "twk-panel";
    panel.hidden = true;
    document.body.appendChild(panel);

    var head = document.createElement("div");
    head.className = "twk-head";
    head.innerHTML = '<b>Tweaks</b>';
    var x = document.createElement("button");
    x.className = "twk-x";
    x.textContent = "×";
    head.appendChild(x);
    panel.appendChild(head);

    var body = document.createElement("div");
    body.className = "twk-body";
    panel.appendChild(body);

    function commit() {
      try { localStorage.setItem(store, JSON.stringify(vals)); } catch (e) {}
      cfg.apply(vals);
    }

    cfg.schema.forEach(function (item) {
      if (item.section) {
        var s = document.createElement("div");
        s.className = "twk-sec";
        s.textContent = item.section;
        body.appendChild(s);
        return;
      }
      var row = document.createElement("div");
      row.className = "twk-row";
      var lab = document.createElement("div");
      lab.className = "twk-lab";
      lab.innerHTML = "<em style='font-style:normal'>" + item.label + "</em>";
      row.appendChild(lab);

      if (item.type === "toggle") {
        lab.style.marginBottom = "0";
        var sw = document.createElement("button");
        sw.className = "twk-sw" + (vals[item.key] ? " on" : "");
        sw.onclick = function () {
          vals[item.key] = !vals[item.key];
          sw.classList.toggle("on", !!vals[item.key]);
          commit();
        };
        lab.appendChild(sw);
      } else if (item.type === "select") {
        var sel = document.createElement("select");
        sel.className = "twk-sel";
        item.options.forEach(function (o) {
          var op = document.createElement("option");
          op.value = o; op.textContent = o;
          if (String(vals[item.key]) === String(o)) op.selected = true;
          sel.appendChild(op);
        });
        sel.onchange = function () { vals[item.key] = sel.value; commit(); };
        row.appendChild(sel);
      } else if (item.type === "slider") {
        var out = document.createElement("span");
        out.textContent = vals[item.key] + (item.unit || "");
        lab.appendChild(out);
        var r = document.createElement("input");
        r.type = "range"; r.className = "twk-range";
        r.min = item.min; r.max = item.max; r.step = item.step || 1;
        r.value = vals[item.key];
        r.oninput = function () {
          vals[item.key] = Number(r.value);
          out.textContent = r.value + (item.unit || "");
          commit();
        };
        row.appendChild(r);
      } else {
        var seg = document.createElement("div");
        seg.className = "twk-seg";
        item.options.forEach(function (o) {
          var b = document.createElement("button");
          b.textContent = o;
          b.className = String(vals[item.key]) === String(o) ? "on" : "";
          b.onclick = function () {
            vals[item.key] = o;
            [].forEach.call(seg.children, function (c) { c.classList.toggle("on", c === b); });
            commit();
          };
          seg.appendChild(b);
        });
        row.appendChild(seg);
      }
      body.appendChild(row);
    });

    var reset = document.createElement("button");
    reset.className = "twk-reset";
    reset.textContent = "Reset to defaults";
    reset.onclick = function () {
      try { localStorage.removeItem(store); } catch (e) {}
      location.reload();
    };
    body.appendChild(reset);

    launch.onclick = function () { panel.hidden = false; launch.hidden = true; };
    x.onclick = function () { panel.hidden = true; launch.hidden = false; };

    cfg.apply(vals);
  };
})();
