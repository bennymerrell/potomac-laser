# Content style rules: banned patterns and required conventions

Goodfellow Group. Applies to all Potomac and Goodfellow web copy, case studies, documents and design deliverables. Issued September 2026 by Andrew Watson, CFO. These rules are instructions, not guidance. They apply to every deliverable, including AI-assisted and AI-generated drafts, and to Claude Design output. A deliverable that breaches them is returned, not amended downstream.

The purpose is simple: our content must read as if written by an engineer who does the work, not by a marketing tool. Several of these patterns were flagged internally by our own engineering leadership as reading as AI-generated. The credibility cost with technical buyers is real.

---

## 1. Punctuation

No em dashes and no en dashes anywhere in rendered text. This includes headings, body copy, tables, captions, CTAs, image alt text, meta descriptions and schema text. Use a comma, a full stop, brackets or a colon instead.

Ranges are written with "to": 2 to 100 µm, 2026 to 2028, 70 to 80%. Not 2–100 µm.

No arrow glyphs appended to link or button text. A button reads "Get a quick quote", not "Get a quick quote →".

Middle-dot separator chains (A · B · C) are permitted only in masthead meta chips and trust bars, where they are established Goodfellow document furniture. Never in body copy or headings.

No semicolons for rhythm or effect. Only where a formal document genuinely requires one.

## 2. Headings

Headings are functional nouns or noun phrases: Specification, Materials, Applications, Outstanding questions, Next steps, Verification register.

Banned heading shapes:
- Conversational or possessive openers: "What we drill...", "How we work", "Why choose us", "What you get"
- Balanced two-part headings with a comma: "What we drill, and to what tolerance"
- Dramatic or narrative headings: "The turning point", "A grand vision", "Patience pays off"
- Question headings, except inside an FAQ block where the question is the content
- Headings with a single accented word (one word bolded, italicised or coloured)
- "Step 1:" prefixes where the layout already numbers the steps

## 3. Banned words and phrases

Never, in any deliverable: leverage, utilise, utilize, seamless, robust, delve, unlock, elevate, empower, harness, unleash, cutting-edge, state-of-the-art, world-class, best-in-class, industry-leading, unparalleled, unmatched, game-changing, revolutionary, synergy, holistic, effortless, excellence, passion, passionate, innovative (as self-description), stunning, exciting, thrilled, "look no further", "in today's", "fast-paced", "ever-evolving", "landscape" (as marketing metaphor), "in order to" (write "to"), "a number of" (write "several" or the number).

Banned in published copy, permitted as internal analytical vocabulary only: "journey" (the customer journey model is an internal framework; the word does not appear on a page), "solutions" as a noun standing in for products or services (job titles such as technical solutions specialist are exempt), "comprehensive", "tailored", "bespoke" (exempt where part of a proper noun, e.g. Bespoke Alloy Systems).

## 4. Banned constructions

- Rule-of-three lists assembled for rhythm ("clear, concise and compelling"). Three items are fine when the content genuinely has three items. See section 6 for the one deliberate exemption.
- "Not just X, but Y" and "more than just".
- Throat-clearing: "it's worth noting", "importantly", "at its core", "fundamentally", "essentially".
- Hedging and balancing: "while X, it's also worth Y", "that said", "on the other hand" as filler.
- Empty amplifiers: "truly", "incredibly", "genuinely" (except where a factual claim of rarity is being made and evidenced).
- Closers: "we hope this helps", "happy to discuss further", "don't hesitate to contact us". End on the point or the ask.
- Attributing drama to process: "The results were immediate", "everything changed". State the numbers and the dates.
- Adjectives doing the work of data: "superior surface quality", "exceptional precision", "guaranteed quality". Every capability claim is a number, a standard, or absent.

## 5. Voice

Engineer-first. Active voice. Plain verbs. Varied sentence length. Claims are numbers with units and stated conditions ("±2 µm, subject to material and thickness review"), never superlatives. British English in internal documents without exception. Page copy on potomac-laser.com follows the site's en-US conventions; use unit symbols (µm, mm) to avoid the spelling divergence where possible. No American idioms in internal documents.

Anything not verified does not get written around; it appears as an empty slot referenced to a verification register.

## 6. Deliberate exemptions

- The group proposition, "Source the material, machine the part, validate the output", is settled brand architecture. It is a deliberate triad and must not be reworded, reordered or stripped.
- The stage model (Discovery, First order, Development, Production) is an internal framework and may be referenced in internal documents by name.
- Masthead meta chips with middle dots, as noted in section 1.
- Direct quotes from named or attributed people are reproduced as spoken, not rewritten to comply.

## 7. Pre-publish check

Before any page, case study or document is signed off, search the rendered text for each of the following and clear every hit: the characters — and – and →, the section 3 word list, "not just", "what we", "how we", "why choose", "it's worth", "in order to". Then read the headings alone, top to bottom: if they read as a narrative or a pitch rather than a table of contents, rewrite them as functional nouns.

Existing internal documents are not being retrospectively scrubbed. Any document is brought into compliance when next reissued. External and publishable content is corrected now: the Cerebras case study (all three versions and the live post), the chip cooling case study draft, and all page copy taken from the wireframes.
