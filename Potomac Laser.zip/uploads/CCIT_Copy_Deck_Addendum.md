# CCIT page: copy deck addendum, 2 September 2026

Approved copy for the sections ported from the first Design build (CCIT.html) into the approved build (CCIT v2.html). Use these words exactly. Nothing else from CCIT.html carries over as text.

---

## A. Sticky in-page navigation

Labels and anchors, in order: Overview (#hero), The science (#science), Methods (#methods), What we make (#what-we-make), Process (#process), FAQ (#faq), plus the persistent button Send your specification (#specification).

---

## B. The science (new section, after the trust bar, before What we make)

Eyebrow: The science

H2: What container closure integrity testing actually proves

CCIT evaluates whether a container closure system maintains a sterile barrier against contaminants: microorganisms, reactive gases and other substances (USP 1207). The barrier must hold for sterile pharmaceutical and biological products across their entire shelf life.

A closure system is built from primary components in direct product contact, such as glass vials and syringes, and secondary components such as aluminium caps over stoppers. To trust a leak detection method, you first have to challenge it with a defect of a known size. That is what a calibrated positive control is.

Callout: Why a known defect matters. A leak detection instrument can only be validated if the positive control it sees is traceable and repeatable. Guess the defect size and you cannot defend the result.

Three stat tiles: 2 µm (smallest calibrated hole, -0 / +2 µm) · 6 (detection methods supported) · ISO 13485:2016 (certified quality system)

---

## C. Methods module (new section, after The science; six cards, tabbed or grid)

Eyebrow: Match your method

H2: Which leak test method are you validating?

Intro line: Calibrated positive controls are compatible with the six common deterministic methods. Pick yours, then send us your container.

Every card ends with the same link: Specify a hole for this method → (#specification)

Card 1. Vacuum decay. Tag: deterministic, pressure rise. A vacuum is drawn around the package and the pressure rise from any leak is monitored. Deterministic and non-destructive, widely used across vials, pouches and blisters. How a calibrated hole supports it: the drilled positive control of known diameter establishes and verifies the method's detection limit during validation and routine re-qualification.

Card 2. Pressure decay. Tag: pressure, time. The package or test volume is pressurised and the pressure drop is monitored over a fixed time, a widely used deterministic method for rigid containers. How a calibrated hole supports it: a positive control at your critical defect size demonstrates that the method resolves it, not just gross failures.

Card 3. High-voltage leak detection (HVLD). Tag: electrical, non-destructive. Changes in electrical conductivity and capacitance are read as a probe passes the container, a deterministic, non-destructive method suited to liquid products. How a calibrated hole supports it: the known-diameter hole is the positive control against which the instrument's sensitivity and reject threshold are validated.

Card 4. Tracer gas, vacuum mode. Tag: helium, mass spectrometry. A tracer gas such as helium is detected by mass spectrometry under vacuum, the most sensitive quantitative approach, used where the tightest integrity limits apply. How a calibrated hole supports it: a measured positive control quantifies the detection threshold your programme must demonstrate.

Card 5. Mass extraction. Tag: vacuum, gas mass flow. Under vacuum, the mass flow of gas escaping the package is measured, a deterministic method used across vials, syringes, pouches and blister packs. How a calibrated hole supports it: the drilled hole provides a traceable, repeatable reference defect for validation and periodic re-verification.

Card 6. Laser headspace analysis (TDLAS). Tag: optical, non-destructive. Tunable diode laser absorption spectroscopy measures headspace oxygen, CO2, moisture or pressure through the container wall without opening it. How a calibrated hole supports it: a defect of defined size lets you establish detection limits by demonstrating how headspace conditions change through it.

Closing line under the cards: Using a method not listed? Tell us the instrument on the form and we will confirm compatibility.

---

## D. Pinhole discs (HELD: do not publish until Mike Davis confirms; build it flagged)

Position: after the spec table, small callout section.

H3: When the container cannot be drilled directly

Some closure systems do not suit direct drilling. In those cases a calibrated hole is drilled into a thin metal disc that affixes over a larger opening in the closure, creating a known, repeatable leak path in the assembled package. The same measurement, NIST-traceable calibration, Certificate of Conformance and Quality Data Sheet apply.

If confirmed, add spec table row: Pinhole discs | Calibrated hole in a metal disc affixed to the closure where direct drilling is unsuitable. Same measurement and documentation.

---

## E. Related applications grid (replaces the single Related line at the foot)

Eyebrow: More applications

H2: Related micro-hole work

Six cards, title, one line, link:
1. Laser micro-hole drilling. The service behind every calibrated hole we make. → /services/micro-hole-drilling/
2. Microfluidic device fabrication. Channels, ports and bonded substrates for lab-on-chip devices. → /application/microfluidics/
3. Probe card drilling. Precise via and guide holes for wafer test probe cards. → /application/probe-cards/
4. Catheter hole drilling. Clean, burr-free holes in balloon and delivery catheters. → /application/catheter-hole-drilling/
5. Invisible backlighting. Micro-perforations for concealed, backlit display icons. → /application/invisible-backlighting/
6. CCIT resource article on goodfellow.com. Background reading on method validation. → goodfellow.com article URL (outbound_click, destination goodfellow_ccit_article)

---

## F. Packaging visual cards (optional layer above the spec table)

Four image cards, captions only, no new claims:
Glass vials and ampoules · Polymer vials and bottles · Foils and blister packs · Pouches, bags and metal containers
Image slots to be filled from Mike Davis's team. No stock imagery. Alt text pattern: "Laser-drilled calibration hole in [container], optical micrograph".

---

## Banned strings (zero occurrences anywhere in the final page, including alt text, titles, hover states and hidden steps)

"1–2 µm" or "1-2 µm" or "as small as 1" · "cracks" · "pinholes" as a description of what our holes resemble (the phrase "pinhole disc" in section D is the exception, and only if Mike confirms) · "SEM" · "all detection tech" or "every major detection technology" · "tailored to method" · "Defect realism"
