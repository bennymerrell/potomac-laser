# CCIT application page: copy deck

Andrew Watson, CFO, Goodfellow Group. 1 September 2026. Approved copy for build.

Rework of the live page at /application/leak-test-hole-drilling/. Publish over the existing URL. Do not change the slug. All copy below is final unless marked; brand name (Potomac Photonics or Goodfellow Microfabrication) to be applied globally at deployment.

Companion file: CCIT_Page_Styled_Draft.html shows layout, section order and table format.

---

## Page metadata

Title tag: CCIT Positive Controls and Calibrated Leak Test Holes | Potomac Photonics

Meta description: Laser-drilled positive controls for container closure integrity testing. USP 1207 and Annex 1 method validation, 2 µm to 100 µm, Certificate of Conformance and Quality Data Sheet with every order.

Breadcrumb: Home > Applications > CCIT and pharmaceutical packaging

Schema: Service, FAQPage (eight questions below, verbatim), BreadcrumbList. Replace the existing Article type.

Internal links: to the micro-hole drilling service page; to the goodfellow.com CCIT resource article (already on the live page, retain); from the generic laser-hole-drilling application page to this page.

Both CTAs anchor to the on-page specification form.

---

## 1. Hero

H1: Laser-drilled calibration holes for container closure integrity testing

Sub: Certified positive controls for USP 1207 and EU Annex 1 method validation. Vials, ampoules, syringes, bottles, IV bags, pouches, foils and blisters, glass, polymer or metal, filled or empty. Hole diameters from 2 µm to 100 µm as standard, larger to order, each hole held to -0 / +2 µm, measured and supplied with a Certificate of Conformance and Quality Data Sheet. Single sets for method development, programme supply for annual re-validation.

Primary CTA: Send your specification
Secondary CTA: Talk to an engineer

---

## 2. Trust bar (six items)

- USP 1207 and EU Annex 1
- FDA and EMA validated methods supported
- CoC and Quality Data Sheet with every order
- NIST-traceable measurement
- Programme supply for re-validation
- ISO 13485:2016

---

## 3. What we make

Eyebrow: What we make

H2: CCIT positive controls drilled into the container your line actually runs

Leak detection equipment only proves what it can find. Vacuum decay, high-voltage leak detection and helium mass spectrometry all need physical defects of known size to establish the detection limit, and USP 1207 requires that those positive controls are characterised, not assumed.

We laser-drill calibrated holes directly into your production containers, glass, polymer or metal, filled or empty, so the artefact matches what your line actually runs. Containers are always customer supplied: a positive control drilled into a generic substitute proves less than one drilled into the container you fill. Holes are compatible with all common deterministic methods, including vacuum decay, HVLD and tracer gas, and we have drilled hundreds of thousands of packages for pharmaceutical, medical device and food customers.

Every hole is measured and recorded, every order ships with a Certificate of Conformance and a Quality Data Sheet, and repeat sets for annual or quarterly re-validation are supplied to the same specification with a fast turnaround.

Callout, titled Programme supply: Re-validation on a programme. Once a specification is on file, repeat sets are quoted and shipped quickly to the same diameters, container and documentation, with no re-specification.

### Specification table

| Parameter | Specification |
|---|---|
| Hole diameter range | 2 µm to 100 µm as standard by percussion drilling. Larger diameters to order. |
| Diameter tolerance | -0 / +2 µm at minimum diameter; ±2 µm otherwise. Filled containers ±5 µm. |
| Container types | Glass and polymer vials (all ISO sizes), ampoules, syringes, pre-filled syringe and autoinjector cartridges, bottles, IV bags, laminate pouches, blister packs and foils, metal containers, COC/COP cryogenic containers |
| Container condition | Empty or filled. Filled vials and syringes are drilled to ±5 µm and priced for the additional fixturing. |
| Hole position | Body, shoulder, neck, seal or closure, to customer drawing. Container base excluded. |
| Detection methods supported | Vacuum decay, pressure decay, HVLD, tracer gas (vacuum mode), mass extraction, laser headspace analysis |
| Measurement | Optical microscopy, equipment calibrated to a NIST-traceable standard, recorded per hole |
| Documentation | Certificate of Conformance and Quality Data Sheet, individual or batch format |
| Lead time | 4 weeks standard. Expedited service available for validation deadlines. |
| Minimum order | None. Single artefacts accepted. |
| Containers | Customer supplied, every order |
| Shipping | US, UK and EU. Drilled in Baltimore, USA; group headquartered in the UK. |

---

## 4. Goodfellow Group bar (navy background, three tiles)

Eyebrow: The Goodfellow Group

H2: One group. Material, artefact and answer.

Tile 1, Potomac Photonics fabricates: Calibrated holes drilled into your own containers, measured, documented, supplied on programme. Link text: Send a specification. Link target: form anchor.

Tile 2, Goodfellow supplies: Pharmaceutical and packaging-grade glass, polymer films and metal foils in the small quantities validation work needs, with material traceability. Link text: Browse packaging materials. Link target: goodfellow.com CCIT resource article.

Tile 3, Suisse Technology Partners investigates: When a package fails CCIT, ISO 17025-accredited failure analysis to find the cause. Link text: Suisse TP laboratory. Link target: suisse-tp.ch, tracked as an outbound event.

Note: the live page's tile text about SEM verification of hole diameter, geometry and wall integrity is withdrawn. Do not carry it over.

---

## 5. How it works

Eyebrow: Process

H2: How it works

01 Send your specification. Container type, material, hole diameter and position, quantity, filled or empty, CoC format, and whether you need re-validation sets on a schedule. A drawing helps; a completed form is enough.

02 We drill and measure. Holes are produced in the containers you send us, then each one is measured on NIST-calibrated equipment and recorded.

03 Delivered with documentation. Certificate of Conformance and Quality Data Sheet with the shipment. Programme customers receive each subsequent set to the same specification, quoted and shipped quickly from the file.

---

## 6. Proof

Eyebrow: Proof

H2: Who relies on it

Testimonial: omitted. Build the section with the case study card only, full width or centred. Do not use any of the six homepage testimonials here.

Case study card:

Eyebrow: Case study

Title: Standing re-validation programme for a contract development and manufacturing organisation

Body: A global CDMO needed positive controls across three container formats for annual method re-validation on multiple sterile lines, and a supplier that could be relied on to answer the phone. Repeat sets to a fixed specification, shipped against a calendar, each with CoC and QDS.

Link text: Read the case study. Link target: to follow; leave unlinked if the case study page is not ready at publication.

The customer is anonymised and must not be named anywhere, including in the case study page, image alt text or URL.

---

## 7. FAQ (eight, verbatim into FAQPage schema)

Eyebrow: Questions validation engineers ask

H2: Frequently asked questions

Q1: What is the smallest hole you can drill for CCIT positive controls?
A1: 2 µm, held to a tolerance of -0 / +2 µm, so the hole is never smaller than nominal. Diameters up to 100 µm are drilled as standard; larger diameters are available to order.

Q2: Do you supply a Certificate of Conformance?
A2: Yes. Every order ships with a Certificate of Conformance and a Quality Data Sheet recording the measured diameter of each hole. Individual or batch certificate formats are available on request.

Q3: Which leak detection methods are your holes compatible with?
A3: Vacuum decay, pressure decay, high-voltage leak detection, tracer gas in vacuum mode, mass extraction and laser-based headspace analysis. If you use a method not listed, tell us the instrument and we will confirm.

Q4: Can you drill filled containers?
A4: Yes. Filled pouches, bags and sealed bottles are routine. Filled vials and syringes are drilled to ±5 µm rather than ±2 µm, because fixturing is more demanding, and are priced accordingly. Tell us on the form so the quotation is right first time.

Q5: Can you drill our own production containers?
A5: Yes, and only yours. We do not hold stock containers. A positive control drilled into the container your line actually runs is a more defensible artefact than a generic substitute, so every order is drilled into customer-supplied containers.

Q6: How do you handle annual re-validation?
A6: On a programme. Once a specification is agreed and on file, repeat sets are quoted and supplied quickly to the same diameters, container and documentation, so annual or quarterly re-validation does not restart the specification process.

Q7: How is hole size verified?
A7: Each hole is measured by optical microscopy on equipment calibrated to a NIST-traceable standard, and the result is recorded on the Quality Data Sheet.

Q8: What is the lead time?
A8: Standard lead time is four weeks, plus shipping. We ship to the US, UK and EU; the group is headquartered in the UK. Expedited service is available for validation deadlines; tell us the date and we will confirm what is possible.

---

## 8. Specification form

Eyebrow: Specification

H2: Send your specification

Fields, in order. Required marked *.

1. Name * (text)
2. Work email * (email)
3. Company * (text)
4. Phone (text)
5. Container type * (select): Glass vial / Polymer vial / Ampoule / Syringe / Cartridge / Bottle / IV bag / Pouch / Blister or foil / Metal container / Other
6. Container material (text; placeholder: e.g. Type I borosilicate, COP, PE laminate)
7. Hole diameter or diameters required (µm) * (text; placeholder: e.g. 5, 10, 20)
8. Hole position (select): Body / Shoulder / Neck / Seal / To drawing / Not sure. Helper text under field: Container base excluded.
9. Quantity per diameter (text)
10. Containers filled or empty at testing (select): Filled / Empty / Not sure
11. Detection method (select): Vacuum decay / Pressure decay / HVLD / Tracer gas (vacuum) / Mass extraction / Laser headspace analysis / Other
12. Certificate format (select): Individual / Batch / No preference
13. Re-validation schedule (select): One-off / Annual / Quarterly / Other
14. Containers (read-only statement): Customer supplied. We will confirm the shipping address on quotation.
15. Drawing or specification (file upload)
16. Anything else (textarea)

Submit button: Send specification

Line beside button: Certificate of Conformance and Quality Data Sheet included with every order. No minimum order.

Every select is a GA4 field-interaction event. Form submission is the primary conversion.

---

## 9. What happens next (three columns)

Eyebrow: What happens next

Now: Your specification reaches the engineering team, not a sales inbox.

Within hours: An engineer confirms the artefact is achievable or asks a specific question.

Within 24 hours: A quotation with lead time.

---

## Deployment notes

- Publish over /application/leak-test-hole-drilling/. No slug change.
- The blog post /blog/focus-biotech-leak-detection-calibration-hole-drilling/ ranks position 6 for the same term this page holds at position 1. Keep it live, add a canonical to this page or a prominent link and CTA to it, and check the other leak-test blog posts for the same treatment.
- Both CTAs and the group-bar tile link must resolve to the form anchor on this page. Test before publish.
- Brand name applied globally at deployment per the group decision.
- Footer address and spelling are a site-wide fix, not part of this page.

---

## Technical specification (Ursula to confirm; CNC benchmark standard)

The page must match the technical layer of goodfellow.com/cnc-micromachining. Items below are the page-specific values; site-wide items (GTM container, Consent Mode v2, LLM allow-list in robots.txt, favicon suite) are assumed in place and should be checked, not rebuilt.

### Head

- `<html lang="en-US">` (potomac-laser.com is a US site; the benchmark's en-GB applies to goodfellow.com)
- Title tag and meta description as in Page metadata above
- Canonical: https://www.potomac-laser.com/application/leak-test-hole-drilling/ (self-referencing)
- hreflang: en-US and x-default only, unless Ursula decides otherwise for this domain. Do not copy the five-entry set from the goodfellow.com page.
- Open Graph: og:title, og:description, og:url, og:type=website, og:image 1200 x 630 (a drilled vial or syringe close-up, no text overlay, no customer identification). Twitter card summary_large_image.
- theme-color and color-scheme per site defaults
- Remove noindex on publish. Confirm sitemap.xml entry and lastmod update.

### Structured data (four JSON-LD blocks)

1. Organization: site-wide block, name per brand decision, sameAs to LinkedIn, parentOrganization Goodfellow.
2. BreadcrumbList: Home > Applications > CCIT and pharmaceutical packaging.
3. Service: name "CCIT positive controls and calibrated leak test holes", serviceType "Laser micro-hole drilling", provider = Organization, areaServed US and GB minimum, description = meta description.
4. FAQPage: the eight questions and answers from section 7, verbatim, exact match to DOM text including punctuation. 8/8 parity is the acceptance test. Validate in Google Rich Results Test before publish.

### Heading hierarchy

One H1 (hero). H2 for each section eyebrow heading as listed. H3 for tile titles, step titles, case study title and each FAQ question. No skipped levels.

### GA4 events (via GTM-KVRK6DFF, data-attribute pattern from the CNC page)

- cta_click: hero primary, hero secondary, group tile 1, form submit button (parameter: cta_location)
- faq_open: each of the eight questions (parameter: faq_id 1 to 8)
- table_view: spec table enters viewport
- form_start: first interaction with any field
- form_field: each select change (parameter: field_name and value) for container_type, hole_position, filled_state, detection_method, certificate_format, revalidation_schedule
- form_upload: file attached
- form_error: validation failure (parameter: field_name)
- form_submit: success, the primary conversion, marked as a key event in GA4
- outbound_click: Suisse TP tile, Goodfellow materials tile, goodfellow.com CCIT article link (parameter: destination)
- case_study_click: card link

Roughly 30 hooks on this page against 46 on the CNC page; the difference is the absence of tabs and basket, not a lower standard.

### Attribution

Append the eleven parameters to every form submission as on the CNC page: utm_source, utm_medium, utm_campaign, utm_content, utm_term, gclid, fbclid, li_fat_id, msclkid, referrer, landing URL, plus first-touch timestamp. The form is the landing page for PPC Campaign 1, so this is not optional.

### Form structure: decision needed

The CNC benchmark uses a two-step progressive disclosure form (contact and upload first, qualification second). The specification form in section 8 is sixteen fields on one step, because a CCIT buyer arrives with a specification and the value of the page is capturing it completely. Options:

- Single step as drafted, all fields visible, with the required fields marked. Simplest, most information per submission, higher abandonment risk.
- Two step: step 1 name, email, company, container type, diameters, upload; step 2 the remaining fields. Matches the benchmark and the GA4 step-transition events.

Recommendation: two step, with step 2 optional and a submit available at the end of step 1. A partial specification with contact details is worth more than an abandoned complete one. Ursula and Ben to confirm the Elementor form can do this; if not, single step.

### Images

Every image needs descriptive alt text stating material and feature (for example "5 µm laser-drilled hole in Type I borosilicate vial wall, optical micrograph"). No customer names or identifiable packaging in any image. Hero image or micrograph to be supplied by Mike Davis's team; do not use stock.

### Acceptance checks before publish

- 0 broken internal links, 0 broken image references, 0 duplicate IDs, 0 nameless buttons
- Both CTAs and the group tile resolve to the form anchor
- Rich Results Test passes for FAQPage, BreadcrumbList and Service
- GA4 DebugView shows form_submit firing with attribution parameters on a test submission
- Search Console: request indexing after publish; check coverage after seven days
