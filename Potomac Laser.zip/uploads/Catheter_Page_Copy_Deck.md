# Catheter page copy deck

Rework of /application/catheter-hole-drilling/. Slug retained. Scope: catheter and medical tubing micro-hole drilling, spoke of the micro-hole drilling hub. Draft for verification, 2 September 2026. Not for publication until every register item is closed.

Convention: [V1] etc marks a claim or figure awaiting verification. The claim text as written is the proposed wording; it is removed or amended, never published as-is, if verification fails. The register at the end lists owner and question for each slot. Copy follows the site's en-US conventions. No em dashes anywhere in rendered output.

---

## Metadata

- Meta title: Catheter Hole Drilling | Laser Micro Holes in Medical Tubing | Potomac Photonics *(brand name applied at deployment per group decision)*
- Meta description: Laser-drilled micro holes in catheters and medical tubing from 2 µm. ±2 µm tolerance, ISO 13485:2016, one-off prototypes to production. Response within 24 hours.
- Slug: /application/catheter-hole-drilling/ (unchanged)

---

## 1. Hero

Eyebrow: Applications

H1: **Catheter hole drilling: laser-drilled micro holes in medical tubing**

Intro: Laser-drilled side holes, ports and vents in catheter and medical tubing, from 2 µm to 100 µm diameter as standard and larger to order [V1]. Single-lumen, multi-lumen and balloon constructions [V2], drilled through one wall with the opposite wall protected [V3]. ISO 13485:2016 certified. From first prototypes to production quantities.

Trust bar: ISO 13485:2016 | Feature tolerance ±2 µm, subject to material and wall review | One wall only, opposite wall protected [V3] | Prototype to production | Goodfellow group traceability

CTAs (both above the fold): **Get a quick quote** | **Talk to an engineer**

---

## 2. Specification table

| Parameter | Specification |
| --- | --- |
| Hole diameter | 2 µm to 100 µm standard by percussion drilling; larger diameters and shaped apertures to order [V1] |
| Feature tolerance | ±2 µm standard, subject to material and thickness review |
| Positional tolerance | As tight as ±2 µm depending on material and part dimension; along and around the tube [V4] |
| Tubing sizes | OD [V5 slot] to [V5 slot]; wall thickness [V5 slot] to [V5 slot] |
| Wall control | Through one wall only; opposite wall protected [V3] |
| Hole geometry | Round holes standard; slots and shaped apertures [V6] |
| Taper | 7 to 10 degrees typical, narrow end at the exit on through holes |
| Quantities | One-off prototypes to production quantities [V7] |

Under-table line (Mike's settled position, hub wording): Tolerance drives cost. Specify the tolerance your device needs, not a preference. We will confirm what is achievable in your material and wall thickness at quoting.

---

## 3. Materials

Catheter and medical tubing polymers are drilled by generic material name. Proposed list, converted from the live page's trade names [V8]:

Polyimide | Nylon (PA) | Pebax (PEBA) | PTFE | Silicone | PET | LDPE | Polystyrene

Line below list: Material not listed? Most medical tubing polymers can be processed. Send the material and wall thickness with your enquiry.

*(Deliberately excluded from this page: fused silica and quartz per the settled service-page correction; no biocompatibility performance claims anywhere. We drill biocompatible materials; we do not claim the drilling enhances biocompatibility.)*

---

## 4. Applications (three cards)

**Drainage and infusion side holes.** Patterns of side holes in single- and multi-lumen tubing for drainage, irrigation and drug delivery. Hole count, spacing and stagger to drawing.

**Balloon catheters.** Micro holes and vents in balloon and inflation constructions [V2].

**Sensor, guidewire and access ports.** Larger shaped apertures and ports cut to drawing [V6] [V9].

---

## 5. Why laser, not mechanical

At these hole sizes, mechanical drilling leaves burrs and debris on a part that will contact tissue, and below roughly 100 µm it stops being practical at all. Laser drilling is non-contact: no cutting forces, no mechanical burr, no tool wear. Because the hole pattern is defined in software rather than tooling, a design change between prototype rounds costs days, not a new tool. Most catheter polymers absorb UV strongly, so the heat-affected zone is low; it is assessed per material and wall thickness at quoting. *(HAZ wording adapted from Mike's hub answer; his sign-off on this adaptation required.)*

---

## 6. How it works (three steps)

1. **Send your drawing or specification.** Material, OD and wall thickness, hole sizes and positions, quantity.
2. **Process development and first articles.** We confirm the process on your material and send first articles for approval before the run [V10a].
3. **Inspection and delivery.** Holes measured by optical microscopy with NIST-traceable calibration; inspection documentation with every order [V10b].

---

## 7. Goodfellow group proposition (mandatory tile)

**Source the material.** Goodfellow supplies over 170,000 catalogue materials, including the polymer films, foils and stock behind many device programs. *(Tubing itself is normally customer supplied [V11]; wording adjusts to the answer.)*

**Machine the part.** Potomac has drilled micro holes in medical tubing and devices for over 40 years, from one-off prototypes to production.

**Validate the output.** Suisse Technology Partners, the group's ISO 17025 accredited laboratory, provides failure analysis and materials characterisation when a device or material needs independent examination. *(Same wording basis as CCIT. No packaged joint offer.)*

---

## 8. Proof

[V12 slot: one anonymised case card (catheter or medical tubing customer, application, hole size, outcome) OR one gallery image (balloon catheter drilling or small holes in tubing) with scale bar and two sentences of context. No testimonial: no unused homepage testimonial remains under the no-repeat rule. Nothing invented.]

---

## 9. FAQ (eight questions, verbatim parity with FAQPage schema)

**1. What size holes can be laser drilled in catheter tubing?**
2 µm to 100 µm diameter as standard by percussion drilling, with larger diameters and shaped apertures to order [V1]. Holes down to roughly 1 µm are possible in prototype and development work, depending on material and thickness.

**2. Can holes be drilled through one wall of the tube only?**
Yes. The process is controlled so the hole passes through the near wall and the opposite wall is protected [V3].

**3. Which catheter materials can be laser drilled?**
Polyimide, nylon, Pebax, PTFE, silicone, PET, LDPE, polystyrene and most other medical tubing polymers [V8]. Send the material and wall thickness with your enquiry and we will confirm.

**4. What tolerances are achievable on catheter hole drilling?**
Feature tolerance of ±2 µm as standard, subject to material and thickness review, with positional tolerance as tight as ±2 µm depending on material and part dimension [V4]. Tolerance drives cost, so specify the tolerance your device needs rather than a preference.

**5. Is there a heat-affected zone?**
There is no single figure; it depends on material, wall thickness and wavelength. Most catheter polymers absorb UV strongly, so the heat-affected zone is low. We assess it for your material at quoting. *(Mike sign-off on adaptation.)*

**6. Can you drill balloon catheters and multi-lumen tubing?**
Yes. We drill single-lumen, multi-lumen and balloon constructions, with hole patterns placed to drawing [V2].

**7. Why use laser drilling rather than mechanical drilling for catheters?**
Laser drilling is non-contact, so there are no cutting forces, no mechanical burr and no tool wear on a part that will contact tissue. The hole pattern is defined in software rather than tooling, so design changes between prototype rounds are fast and carry no tooling cost.

**8. What quantities and lead times do you support?**
From single prototypes to production quantities [V7]. Typical lead time [V13 slot], with expedite available. Quotes are returned within 24 hours of a complete specification [V14].

---

## 10. Enquiry form and closing band

Structured form, not a generic contact form. Fields: tubing material | OD and wall thickness | hole diameter(s) | number of holes and pattern | construction (single-lumen, multi-lumen, balloon) | quantity | prototype or production | target date | drawing upload.

Form structure (single-step vs two-step with submit after step one) follows the CCIT decision once Ben and Ursula answer on Elementor capability. Same open decision, same resolution.

What happens next band, directly above the form: **Now:** confirmation of receipt. **Within hours:** an engineer reviews your drawing. **Within 24 hours:** a quote, or our questions back [V14].

---

## Verification register

Jacob Adelstein has left the business. His items are merged into the Mike Davis questionnaire for now; the commercial confirmations (V13, V14) may pass to Ron Clawson.

| Ref | Question | Owner | Status |
| --- | --- | --- | --- |
| V1 | Does the 2 to 100 µm standard range (and roughly 1 µm development figure) hold on curved tubing surfaces, not just flat stock? | Mike Davis | Pending |
| V2 | Balloon and multi-lumen drilling confirmed, and whether production or prototype only | Mike Davis | Pending |
| V3 | Single-wall drilling with opposite wall protected: confirmed capability and correct wording | Mike Davis | Pending |
| V4 | Positional accuracy along and around the tube; is rotary-axis drilling offered | Mike Davis | Pending |
| V5 | Tubing OD and wall thickness range (min and max) | Mike Davis | Pending |
| V6 | Hole shapes beyond round: slots, shaped apertures, skived-style windows | Mike Davis | Pending |
| V7 | Do production catheter runs exist today, or is this prototype-weighted; typical quantities | Mike Davis | Pending |
| V8 | Materials list by generic name; any that are IR-only or excluded | Mike Davis | Pending |
| V9 | What catheter enquiries actually are (drainage, balloon, ports, other) | Mike Davis | Pending |
| V10 | (a) First-article step standard practice? (b) What inspection documentation ships with catheter orders (CoC, inspection report, none) | Mike Davis | Pending |
| V11 | Tubing customer supplied as standard, or sourced | Mike Davis | Pending |
| V12 | Proof asset: anonymised case card or gallery image with scale bar | Mike Davis | Pending |
| V13 | Typical lead time wording (do not reuse the CCIT four weeks without confirmation) | Mike Davis / Ron Clawson | Pending |
| V14 | Response commitments (within hours, within 24 hours) apply to catheter work | Mike Davis | Pending |

Also required before build is signed off: Mike Davis's sign-off on the HAZ adaptation (section 5 and FAQ 5) and the tolerance line under the spec table.

---

## Deployment and technical notes

- Slug retained: /application/catheter-hole-drilling/. No redirect required.
- Remove from the live page: the 2 µm vs tens of micrometers contradiction (resolved by the verified spec table); the non-thermal processing claim; automated real-time quality control; guaranteed quality; enhanced biocompatibility; the Rapid Response block and its email, drawing and chat links.
- Both CTAs resolve to the on-page form anchor. The #quote anchor fault on the service pages must not be replicated here.
- Internal links: parent hub /services/micro-hole-drilling/ (this page is a spoke); cross-links to /application/leak-test-hole-drilling/ and /application/probe-cards/; material link to /material/kapton-polyimide/.
- Technical specification per the CCIT build: canonical self-referencing; hreflang en-US and x-default only; OG image 1200 x 630; four JSON-LD blocks (Organization, BreadcrumbList, Service, FAQPage with 8/8 verbatim parity); GA4 hooks and eleven attribution parameters on form submission per the CCIT specification; acceptance checks before publish; Search Console indexing request on republish.
- Brand name (Potomac Photonics vs Goodfellow Microfabrication) applied by Ben at deployment per the group decision.
- Testimonials: none on this page. Proof slot only.
