# Handoff: About Our Group (Goodfellow Microfabrication)

## Overview
Marketing "About Our Group" page for **Goodfellow Microfabrication** (formerly Potomac Photonics / Potomac Laser). It introduces the four specialist brands of the Goodfellow Group and drives visitors toward a quote request. This handoff reflects the **"no hero" variant** — the top hero banner has been removed; the page opens directly on the "Why Us" group intro.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the intended look and behavior, not production code to ship directly. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, etc.) using its established components, tokens, and patterns. If no environment exists yet, pick the most appropriate framework and implement there.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, and layout are final. Recreate pixel-for-pixel using the codebase's existing libraries. All design values are tokenized in `assets/tokens.css` (CSS custom properties) — map these to the target system's tokens.

## Variant note — "No hero"
This page is the version with the **hero banner removed**. In the original prototype the hero was toggled off via a Tweaks panel (`showHero: false`); here it is physically deleted and the tweak machinery (React/Babel tweaks panel) is stripped out. All other options remain at their defaults:
- Brand blocks: **Alternating** image/text layout
- Block spacing: **96px** between blocks
- Block visuals: shown · Block stats: shown · Brand legend (overview grid): shown

Do **not** implement the hero. The page's first section is "Why Us".

## Screens / Views

### 1. Why Us (group intro) — page top
- **Purpose:** Orient the visitor: four specialist brands, one group; jump-links to each brand block.
- **Layout:** Full-width section with a subtle wash background (`--bg-subtle`), centered content in a `--maxw` container. Centered header (eyebrow + H2 + lede, lede capped ~760px), then a responsive brand legend grid below.
- **Components:**
  - **Eyebrow** — "Why Us", magenta variant, uppercase, `0.12em` tracking, centered.
  - **H2** — "Four specialist brands. One Goodfellow Group." Display font (Nunito), `--fg-1`.
  - **Lede** — body copy, `--fg-2`, centered, max-width ~760px.
  - **Brand legend** — grid: 2 columns mobile, **4 columns ≥880px**, `14px` gap. Each item is an `<a>` jump-link (card): column flex, `18px 20px` padding, `--bg-page` fill, `1px --border-1` border, `--r-md` radius. Contains a colored dot + brand name (Nunito 600, `--fs-18`) and an uppercase role label (`--fs-13`, `--fg-3`, `0.08em` tracking).
    - Dots: Goodfellow `--gf-blue`, Microfabrication `--gf-magenta`, Suisse TP `--logo-teal`, BAS `--logo-orange`.
    - **Hover:** `translateY(-2px)`, `--shadow-2`, border → `--border-strong`.

### 2. Brand blocks (×4)
- **Purpose:** One detailed row per brand: Goodfellow, Goodfellow Microfabrication, Suisse Technology Partners, Bureau of Analysed Samples.
- **Layout:** `.brand-row` — single column mobile; **≥980px: two columns `1fr 1fr`, `72px` gap.** Rows alternate visual side: odd rows visual left, even rows (`.brand-row--rev`) visual right (`order:2` on ≥980px). **`96px` vertical gap between rows.**
- **Components per row:**
  - **Visual panel** (`.brand-row__visual`): `16/10` aspect ratio, `--bg-page` fill (white in `--section--subtle`), `1px --border-1` border, `--r-lg` radius, `--shadow-1`, `48px` padding, centered logo image (`max-width:78%`, `max-height:64%`, `object-fit:contain`).
    - Top accent bar (`.brand-row__accent`): `4px` tall, full-width, brand color.
    - "Founded" pill (`.brand-row__founded`): bottom-right, mono font, `--fs-12`, `--bg-subtle`, `--r-pill`. Values: Goodfellow "Since 1946", Microfabrication "Since 1982", Suisse "Swiss labs", BAS "Since 1935".
  - **Text column:**
    - Eyebrow with colored dot (role label, brand color, `0.12em` tracking).
    - Title (`.brand-row__title`): Nunito 600, `clamp(1.7rem, 2.6vw, 2.25rem)`, `-0.02em` tracking, `--fg-1`.
    - Lead (`.brand-row__lead`): `--fs-16`, weight 600, `--fg-1`.
    - Body (`.brand-row__body`): `--fs-16`, `1.7` line-height, `--fg-2`, `text-wrap: pretty`.
    - Stats row: pills (`.brand-row__stat`) — `--bg-subtle`, `1px --border-1`, `--r-pill`, `6px 13px`; `<strong>` in display font. 3 per brand.
    - CTA: primary button (see tokens). Text/links per brand (Visit Goodfellow →, Explore microfabrication →, Visit Suisse TP →, Visit BAS →).

### 3. Final CTA — page bottom
- **Purpose:** Convert to a quote.
- **Layout:** Full-width dark navy panel, centered content.
- **Components:** on-dark eyebrow "One Partner, End to End"; H2 "From material to finished micro-part."; copy paragraph; two buttons — primary CTA "Request a quote" (→ `CNC Micromachining.html#quote`), ghost-light "View the project gallery" (→ `Project Gallery.html`).

## Interactions & Behavior
- **Reveal-on-scroll:** elements with `.reveal` fade in + rise 18px when scrolled into view (IntersectionObserver, `threshold 0.08`). Staggered variants `d1…d5` add `80ms` delays. Respect `prefers-reduced-motion` (show immediately). A load-time safety net reveals everything if no intersection fires within 400ms.
- **Hover:** legend items and brand visuals lift with a stronger shadow; buttons lift `-1px` and darken; links shift to orange/brand color.
- **Jump-links:** brand-legend items anchor to `#goodfellow`, `#potomac`, `#suisse`, `#bas`.
- **Signature easing:** `cubic-bezier(.25,.46,.45,.94)` for all transitions.

## State Management
None. This is a static content page — no client state beyond scroll-reveal observers.

## Design Tokens
All values are CSS custom properties in **`assets/tokens.css`** — the source of truth. Key ones:
- **Brand color:** orange accent `#F5821F` (CTAs, eyebrow rules, stat numbers); navy `#15253D` / `#1D3557` (headings, dark panels).
- **Divisional accents:** `--gf-blue`, `--gf-magenta`, `--logo-teal`, `--logo-orange`.
- **Neutrals:** `--fg-1/2/3` text, `--border-1` / `--border-strong`, `--bg-page` / `--bg-subtle` washes.
- **Type:** Nunito 800/900 display (`--font-display`), Nunito Sans body (`--fs-12`…`--fs-18`), a mono for captions/pills (`--font-mono`).
- **Radii:** `--r-md` cards, `--r-lg` panels, `--r-pill` chips/buttons.
- **Shadows:** `--shadow-1` card, `--shadow-2` raised.
- **Layout:** `--maxw` container width, `24px` gutters.
- **Motion:** `--dur-med` duration, `--ease-out` easing.

Consult `styles.css` for the shared component classes (`.hero`, `.section`, `.eyebrow`, `.btn`, `.final-cta`, etc.); page-specific rules are in the `<style>` block at the top of the HTML file.

## Assets
- **Brand logos** (referenced by absolute URL from potomac-laser.com):
  - Goodfellow Advanced Materials, Goodfellow Microfabrication, Suisse Technology Partners, Bureau of Analysed Samples logos.
  - Replace these with locally-hosted brand assets in production.
- **Fonts:** Nunito + Nunito Sans via Google Fonts (`<link>` in `<head>`).
- No hero imagery (hero removed in this variant).

## Files
- `About Our Group (no hero).html` — the design reference (hero removed, tweak machinery stripped).
- `styles.css` — shared Goodfellow Microfabrication component styles.
- `assets/tokens.css` — all design tokens (colors, type, spacing, radii, shadows, motion).
