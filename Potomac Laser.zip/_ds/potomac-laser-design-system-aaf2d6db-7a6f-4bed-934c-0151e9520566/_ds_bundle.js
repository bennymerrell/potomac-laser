/* @ds-bundle: {"format":3,"namespace":"GoodfellowMicrofabricationDesignSystem_aaf2d6","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"StatBlock","sourcePath":"components/core/StatBlock.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"FaqItem","sourcePath":"components/feedback/FaqItem.jsx"},{"name":"FileUpload","sourcePath":"components/forms/FileUpload.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"3e60a36ac15c","components/core/Button.jsx":"014aa1466825","components/core/Card.jsx":"d24597b8c2a4","components/core/Eyebrow.jsx":"be67cbec3923","components/core/StatBlock.jsx":"e6649f121eca","components/core/Tag.jsx":"d91e38c7d99f","components/feedback/FaqItem.jsx":"f6f419c04ad9","components/forms/FileUpload.jsx":"7d8c81f870e2","components/forms/Input.jsx":"0154c4a6efc8","components/forms/Select.jsx":"95c09cee5447","components/forms/Textarea.jsx":"04dc9b9bd32a","ui_kits/microfabrication-site/app.jsx":"6be1afb32cff","ui_kits/microfabrication-site/data.js":"47d6c9df2a2b","ui_kits/microfabrication-site/sections1.jsx":"1a56ba132891","ui_kits/microfabrication-site/sections2.jsx":"c098e8b323a4","ui_kits/microfabrication-site/sections3.jsx":"de57101c5844"},"inlinedExternals":[],"unexposedExports":[{"name":"fieldBase","sourcePath":"components/forms/Input.jsx"},{"name":"labelStyle","sourcePath":"components/forms/Input.jsx"}]} */

(() => {

const __ds_ns = (window.GoodfellowMicrofabricationDesignSystem_aaf2d6 = window.GoodfellowMicrofabricationDesignSystem_aaf2d6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Badge
 * Emphasized "proof chip": a small pill that calls out a credential or
 * spec (e.g. "±5 µm achievable", "ISO 13485 aligned"). Orange is the
 * default; rose is the secondary proof accent; teal reads on dark panels.
 */
function Badge({
  children,
  tone = 'orange',
  solid = false,
  style,
  ...rest
}) {
  const tones = {
    orange: solid ? {
      background: 'var(--orange)',
      color: '#fff',
      border: '1px solid var(--orange)'
    } : {
      background: 'var(--orange-100)',
      color: 'var(--orange)',
      border: '1px solid rgba(245,130,31,0.28)'
    },
    rose: solid ? {
      background: 'var(--rose)',
      color: '#fff',
      border: '1px solid var(--rose)'
    } : {
      background: 'var(--rose-50)',
      color: 'var(--rose-text)',
      border: '1px solid var(--rose-border)'
    },
    navy: solid ? {
      background: 'var(--navy)',
      color: '#fff',
      border: '1px solid var(--navy)'
    } : {
      background: 'rgba(21,37,61,0.06)',
      color: 'var(--navy-mid)',
      border: '1px solid transparent'
    },
    teal: {
      background: 'rgba(107,208,227,0.12)',
      color: 'var(--teal)',
      border: '1px solid rgba(107,208,227,0.30)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      borderRadius: 'var(--radius-pill)',
      padding: '5px 12px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-eyebrow)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '0.01em',
      lineHeight: 1.3,
      whiteSpace: 'nowrap',
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Button
 * Pill-shaped, uppercase, wide-tracked. Orange primary carries the
 * signature glow shadow; secondary is white/navy outline; ghost is a
 * tracked text link, usually with a → arrow.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  arrow = false,
  fullWidth = false,
  disabled = false,
  href,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '10px 20px',
      fontSize: 'var(--fs-2xs)'
    },
    md: {
      padding: '14px 28px',
      fontSize: 'var(--fs-2xs)'
    },
    lg: {
      padding: '16px 34px',
      fontSize: 'var(--fs-xs)'
    }
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-extrabold)',
    textTransform: 'uppercase',
    letterSpacing: 'var(--ls-wide)',
    lineHeight: 1,
    borderRadius: 'var(--radius-pill)',
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'background var(--dur-base) var(--ease-brand), color var(--dur-base) var(--ease-brand), border-color var(--dur-base) var(--ease-brand), transform var(--dur-base) var(--ease-brand), box-shadow var(--dur-base) var(--ease-brand)',
    width: fullWidth ? '100%' : 'auto',
    border: '2px solid transparent',
    whiteSpace: 'nowrap',
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: 'var(--orange)',
      color: '#fff',
      boxShadow: 'var(--shadow-orange-soft)'
    },
    secondary: {
      background: '#fff',
      color: 'var(--navy)',
      borderColor: 'var(--gray-300)'
    },
    'dark-outline': {
      background: 'transparent',
      color: '#fff',
      borderColor: 'rgba(255,255,255,0.35)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--gray-500)',
      letterSpacing: 'var(--ls-eyebrow)',
      padding: size === 'lg' ? '12px 14px' : '8px 10px'
    }
  };
  const hoverStyles = {
    primary: {
      background: 'var(--orange-dark)',
      transform: 'translateY(-1px)',
      boxShadow: 'var(--shadow-orange)'
    },
    secondary: {
      background: 'var(--navy)',
      color: '#fff',
      borderColor: 'var(--navy)'
    },
    'dark-outline': {
      background: 'rgba(255,255,255,0.10)',
      borderColor: '#fff'
    },
    ghost: {
      color: 'var(--orange)'
    }
  };
  const [hover, setHover] = React.useState(false);
  const composed = {
    ...base,
    ...variants[variant],
    ...(hover && !disabled ? hoverStyles[variant] : null),
    ...style
  };
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, children, arrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: '1.1em',
      lineHeight: 1
    }
  }, "\u2192"));
  const handlers = {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  };
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href,
      style: composed,
      onClick: onClick
    }, handlers, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    style: composed,
    onClick: onClick,
    disabled: disabled
  }, handlers, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Card
 * The base surface: white, hairline border, 8px radius, soft shadow.
 * `interactive` adds a hover lift + navy-tinted shadow; `selected`
 * fills the orange wash, keeps an orange border, and shows a ✓ badge;
 * `accentBar` reveals an orange underline that scales in on hover.
 */
function Card({
  children,
  interactive = false,
  selected = false,
  accentBar = false,
  padding = 'var(--space-6)',
  radius = 'var(--radius-card)',
  tone = 'light',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const toneBase = {
    light: {
      background: 'var(--surface-card)',
      borderColor: 'var(--gray-200)'
    },
    quiet: {
      background: 'var(--surface-quiet)',
      borderColor: 'var(--gray-200)'
    }
  }[tone];
  const base = {
    position: 'relative',
    overflow: 'hidden',
    background: toneBase.background,
    border: `${interactive ? 'var(--bw-card)' : 'var(--bw-hairline)'} solid ${toneBase.borderColor}`,
    borderRadius: radius,
    padding,
    boxShadow: 'var(--shadow-card)',
    transition: 'border-color var(--dur-base) var(--ease-brand), box-shadow var(--dur-base) var(--ease-brand), transform var(--dur-base) var(--ease-brand), background var(--dur-base) var(--ease-brand)',
    cursor: interactive ? 'pointer' : 'default'
  };
  const hovered = interactive && hover && !selected ? {
    borderColor: 'var(--orange)',
    boxShadow: 'var(--shadow-hover)',
    transform: 'translateY(-2px)'
  } : null;
  const selectedStyle = selected ? {
    borderColor: 'var(--orange)',
    background: 'var(--orange-soft)'
  } : null;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...base,
      ...hovered,
      ...selectedStyle,
      ...style
    },
    onMouseEnter: interactive ? () => setHover(true) : undefined,
    onMouseLeave: interactive ? () => setHover(false) : undefined
  }, rest), children, accentBar && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      height: '3px',
      background: 'var(--orange)',
      transform: hover ? 'scaleX(1)' : 'scaleX(0)',
      transformOrigin: 'left',
      transition: 'transform var(--dur-slow) var(--ease-brand)'
    }
  }), selected && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      top: '10px',
      right: '12px',
      width: '22px',
      height: '22px',
      background: 'var(--orange)',
      color: '#fff',
      borderRadius: '50%',
      fontSize: '12px',
      fontWeight: 'var(--fw-extrabold)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, "\u2713"));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Eyebrow
 * The signature section kicker: a short orange rule + uppercase,
 * wide-tracked label. Opens nearly every section. Variants control
 * whether the leading rule shows and which surface it sits on.
 */
function Eyebrow({
  children,
  rule = true,
  tone = 'orange',
  align = 'left',
  as = 'div',
  style,
  ...rest
}) {
  const Tag = as;
  const toneColor = {
    orange: 'var(--orange)',
    'on-dark': 'var(--orange)',
    muted: 'var(--gray-400)'
  }[tone];
  const ruleColor = tone === 'muted' ? 'var(--gray-300)' : 'var(--orange)';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: align === 'center' ? 'center' : 'flex-start',
      gap: '12px',
      ...style
    }
  }, rest), rule && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: '32px',
      height: '2px',
      background: ruleColor,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-eyebrow)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: toneColor
    }
  }, children));
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — StatBlock
 * A single proof statistic: big orange extrabold value + uppercase
 * muted caption. Designed to sit in a divider-separated row (see
 * `divider` prop) as in the hero stat strip.
 */
function StatBlock({
  value,
  label,
  tone = 'on-dark',
  divider = false,
  style,
  ...rest
}) {
  const captionColor = tone === 'on-dark' ? 'rgba(255,255,255,0.40)' : 'var(--gray-400)';
  const borderColor = tone === 'on-dark' ? 'rgba(255,255,255,0.10)' : 'var(--gray-200)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      paddingBottom: '8px',
      paddingLeft: divider ? '20px' : 0,
      borderLeft: divider ? `1px solid ${borderColor}` : 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-extrabold)',
      color: 'var(--orange)',
      fontSize: '1.55rem',
      lineHeight: 1,
      letterSpacing: 'var(--ls-tight)',
      marginBottom: '4px'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-micro)',
      fontWeight: 'var(--fw-semibold)',
      textTransform: 'uppercase',
      letterSpacing: '0.06em',
      color: captionColor
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Tag
 * Neutral metadata pill (material forms, categories, applications).
 * Quieter than Badge — gray fill, gray text, hairline border.
 */
function Tag({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      borderRadius: 'var(--radius-pill)',
      padding: '3px 10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-micro)',
      fontWeight: 'var(--fw-bold)',
      color: '#475569',
      background: 'var(--gray-100)',
      border: '1px solid var(--gray-200)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/FaqItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — FaqItem
 * Accordion row: bold navy question + circular +/× toggle that rotates
 * and fills orange when open; answer expands via max-height transition.
 * Controlled (open/onToggle) or uncontrolled (defaultOpen).
 */
function FaqItem({
  question,
  children,
  defaultOpen = false,
  open,
  onToggle,
  last = false,
  style,
  ...rest
}) {
  const [internalOpen, setInternalOpen] = React.useState(defaultOpen);
  const isControlled = open !== undefined;
  const isOpen = isControlled ? open : internalOpen;
  const [hover, setHover] = React.useState(false);
  const toggle = () => {
    if (isControlled) onToggle && onToggle(!isOpen);else setInternalOpen(v => !v);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderBottom: last ? 'none' : '1px solid var(--gray-100)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: toggle,
    "aria-expanded": isOpen,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: '100%',
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      padding: '20px 0',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '20px',
      textAlign: 'left',
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-body)',
      fontWeight: 'var(--fw-bold)',
      color: hover || isOpen ? 'var(--orange)' : 'var(--navy-mid)',
      transition: 'color var(--dur-base)'
    }
  }, question, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: '28px',
      height: '28px',
      borderRadius: '50%',
      border: `1.5px solid ${isOpen ? 'var(--orange)' : 'var(--gray-300)'}`,
      background: isOpen ? 'var(--orange)' : 'transparent',
      color: isOpen ? '#fff' : 'var(--gray-500)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '18px',
      flexShrink: 0,
      transform: isOpen ? 'rotate(45deg)' : 'none',
      transition: 'transform var(--dur-base), background var(--dur-base), border-color var(--dur-base), color var(--dur-base)'
    }
  }, "+")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: isOpen ? '600px' : '0',
      overflow: 'hidden',
      transition: 'max-height var(--dur-slow) var(--ease-brand)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: '20px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-sm)',
      color: 'var(--gray-500)',
      lineHeight: 'var(--lh-relaxed)'
    }
  }, children)));
}
Object.assign(__ds_scope, { FaqItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/FaqItem.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const labelStyle = {
  display: 'block',
  margin: '0 0 8px',
  fontFamily: 'var(--font-sans)',
  fontSize: 'var(--fs-micro)',
  fontWeight: 'var(--fw-extrabold)',
  letterSpacing: 'var(--ls-wider)',
  textTransform: 'uppercase',
  color: 'var(--gray-600)'
};
const fieldBase = {
  width: '100%',
  boxSizing: 'border-box',
  border: '1px solid var(--border-input)',
  background: '#fff',
  borderRadius: 'var(--radius-md)',
  padding: '13px 16px',
  fontFamily: 'var(--font-sans)',
  fontSize: 'var(--fs-sm)',
  lineHeight: 1.4,
  color: '#1F2937',
  transition: 'border-color var(--dur-base), box-shadow var(--dur-base)'
};

/**
 * Goodfellow Microfabrication — Input
 * Labeled text field. Uppercase tracked label (orange * when required),
 * 12px-radius field, orange focus ring.
 */
function Input({
  label,
  required = false,
  id,
  type = 'text',
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || (label ? `in-${String(label).toLowerCase().replace(/[^a-z0-9]+/g, '-')}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: labelStyle
  }, label, " ", required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--orange)'
    }
  }, "*")), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...fieldBase,
      ...(focus ? {
        outline: 'none',
        borderColor: 'var(--orange)',
        boxShadow: 'var(--focus-ring)'
      } : null),
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { Input, labelStyle, fieldBase });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/FileUpload.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — FileUpload
 * CAD/drawing upload field. Orange pill "choose file" button + helper
 * hint line ("STEP, STL, IGES, PDF, DXF, DWG, or ZIP up to 25 MB").
 */
function FileUpload({
  label = 'Upload drawing / CAD',
  hint = 'STEP, STL, IGES, PDF, DXF, DWG, or ZIP up to 25 MB',
  accept = '.step,.stp,.stl,.iges,.igs,.pdf,.dxf,.dwg,.zip',
  id = 'cad-upload',
  style,
  wrapperStyle,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: __ds_scope.labelStyle
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-input)',
      borderRadius: 'var(--radius-md)',
      padding: '12px 14px',
      background: '#fff',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: "file",
    accept: accept,
    style: {
      width: '100%',
      fontSize: 'var(--fs-xs)',
      color: 'var(--gray-500)',
      fontFamily: 'var(--font-sans)'
    }
  }, rest))), hint && /*#__PURE__*/React.createElement("small", {
    style: {
      display: 'block',
      marginTop: '8px',
      fontSize: 'var(--fs-2xs)',
      color: 'var(--gray-400)',
      fontFamily: 'var(--font-sans)'
    }
  }, hint), /*#__PURE__*/React.createElement("style", null, `
        #${id}::file-selector-button{
          border:0;border-radius:var(--radius-pill);
          background:var(--orange-100);color:var(--orange);
          font-weight:var(--fw-extrabold);font-size:11px;
          padding:8px 14px;margin-right:10px;cursor:pointer;
          font-family:var(--font-sans);
          transition:background var(--dur-base);
        }
        #${id}::file-selector-button:hover{background:#FCE3CC;}
      `));
}
Object.assign(__ds_scope, { FileUpload });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FileUpload.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Select
 * Labeled dropdown matching the form field styling. Pass options as
 * an array of strings or {value,label} objects, or render <option>
 * children directly.
 */
function Select({
  label,
  required = false,
  id,
  options,
  placeholder,
  children,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || (label ? `sel-${String(label).toLowerCase().replace(/[^a-z0-9]+/g, '-')}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: __ds_scope.labelStyle
  }, label, " ", required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--orange)'
    }
  }, "*")), /*#__PURE__*/React.createElement("select", _extends({
    id: inputId,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...__ds_scope.fieldBase,
      appearance: 'none',
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpath d='M1 1l5 5 5-5'/%3E%3C/svg%3E\")",
      backgroundRepeat: 'no-repeat',
      backgroundPosition: 'right 16px center',
      paddingRight: '40px',
      cursor: 'pointer',
      ...(focus ? {
        outline: 'none',
        borderColor: 'var(--orange)',
        boxShadow: 'var(--focus-ring)'
      } : null),
      ...style
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options ? options.map(o => {
    const value = typeof o === 'string' ? o : o.value;
    const text = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, text);
  }) : children));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Goodfellow Microfabrication — Textarea
 * Multi-line variant of the form field; min-height 96px, vertical resize.
 */
function Textarea({
  label,
  required = false,
  id,
  rows = 4,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || (label ? `ta-${String(label).toLowerCase().replace(/[^a-z0-9]+/g, '-')}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: __ds_scope.labelStyle
  }, label, " ", required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--orange)'
    }
  }, "*")), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...__ds_scope.fieldBase,
      minHeight: '96px',
      resize: 'vertical',
      ...(focus ? {
        outline: 'none',
        borderColor: 'var(--orange)',
        boxShadow: 'var(--focus-ring)'
      } : null),
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// ui_kits/microfabrication-site/app.jsx
try { (() => {
/* global React, ReactDOM */
const NSA = window.GoodfellowMicrofabricationDesignSystem_aaf2d6;
function BasketDrawer({
  open,
  items,
  onClose,
  onRemove
}) {
  const {
    Button,
    Tag,
    Textarea,
    Select
  } = NSA;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,.35)',
      zIndex: 499,
      opacity: open ? 1 : 0,
      pointerEvents: open ? 'all' : 'none',
      transition: 'opacity .3s'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      right: 0,
      top: 0,
      bottom: 0,
      width: 360,
      background: '#fff',
      zIndex: 500,
      boxShadow: 'var(--shadow-drawer)',
      transform: open ? 'translateX(0)' : 'translateX(100%)',
      transition: 'transform .35s var(--ease-brand)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '16px 20px',
      borderBottom: '1px solid var(--gray-100)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      fontSize: 16,
      margin: 0
    }
  }, "Material + Machining Basket"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--gray-400)',
      margin: '2px 0 0'
    }
  }, "Material, machining & validation in one request")), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      width: 32,
      height: 32,
      borderRadius: '50%',
      background: 'var(--gray-100)',
      border: 'none',
      cursor: 'pointer',
      fontSize: 18,
      color: 'var(--gray-500)'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '16px 20px'
    }
  }, items.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 0'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--gray-400)',
      fontWeight: 600,
      margin: 0
    }
  }, "Your basket is empty"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--gray-300)',
      margin: '4px 0 0'
    }
  }, "Add a material from Applications to start")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, items.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.id,
    style: {
      background: 'var(--gray-50)',
      border: '1px solid var(--gray-200)',
      borderRadius: 8,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 8,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      color: 'var(--navy-mid)',
      fontSize: 13
    }
  }, b.name), /*#__PURE__*/React.createElement("button", {
    onClick: () => onRemove(b.id),
    style: {
      color: 'var(--gray-300)',
      background: 'none',
      border: 'none',
      fontSize: 18,
      lineHeight: 1,
      cursor: 'pointer'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 6
    }
  }, b.forms.slice(0, 2).map(f => /*#__PURE__*/React.createElement(Tag, {
    key: f
  }, f))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--gray-400)'
    }
  }, "Supplied by Goodfellow Materials"))))), items.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--gray-100)',
      padding: '16px 20px',
      background: 'var(--gray-50)',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      color: 'var(--navy-mid)',
      fontSize: 13
    }
  }, "Machining requirements"), /*#__PURE__*/React.createElement(Textarea, {
    label: "Part description",
    rows: 2,
    placeholder: "e.g. Microfluidic chip, 150 \xB5m channels, 3 layers"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Tolerance",
    placeholder: "Select\u2026",
    options: ['±10 µm (standard)', '±5 µm (precision)', 'Sub-5 µm (discuss)']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px 20px',
      borderTop: '1px solid var(--gray-100)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    arrow: true,
    disabled: items.length === 0
  }, "Request Material + Machining Quote"), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      fontSize: 10,
      color: 'var(--gray-300)',
      margin: '8px 0 0'
    }
  }, "No commitment. Our engineers respond within 24 hours."))));
}
function App() {
  const [basket, setBasket] = React.useState([]);
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const addMaterial = m => {
    setBasket(b => b.find(x => x.id === m.id) ? b : [...b, m]);
    setDrawerOpen(true);
  };
  const removeMaterial = id => setBasket(b => b.filter(x => x.id !== id));
  return /*#__PURE__*/React.createElement("div", {
    "data-scroll-root": true,
    style: {
      height: '100vh',
      overflowY: 'auto',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement(window.Nav, {
    basketCount: basket.length,
    onOpenBasket: () => setDrawerOpen(true)
  }), /*#__PURE__*/React.createElement(window.Hero, null), /*#__PURE__*/React.createElement(window.WhySection, null), /*#__PURE__*/React.createElement(window.ServicesSection, null), /*#__PURE__*/React.createElement(window.ApplicationsSection, {
    onAddMaterial: addMaterial
  }), /*#__PURE__*/React.createElement(window.WorkflowSection, null), /*#__PURE__*/React.createElement(window.QuoteSection, {
    basketCount: basket.length
  }), /*#__PURE__*/React.createElement(window.FaqSection, null), /*#__PURE__*/React.createElement(window.CtaSection, null), /*#__PURE__*/React.createElement(window.Footer, null), /*#__PURE__*/React.createElement(BasketDrawer, {
    open: drawerOpen,
    items: basket,
    onClose: () => setDrawerOpen(false),
    onRemove: removeMaterial
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/microfabrication-site/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/microfabrication-site/data.js
try { (() => {
// Goodfellow Microfabrication — UI kit data (materials, applications, services, FAQ)
// Plain data module; attaches to window for the Babel-scoped section files.
window.GFM_DATA = {
  services: [{
    title: 'CNC Micromachining',
    img: '../../assets/imagery/cnc-micromachining.jpg',
    copy: '4-axis CNC milling and drilling for fine-feature metals and engineering plastics where repeatable tolerance control matters.'
  }, {
    title: 'Laser Micromachining',
    img: '../../assets/imagery/laser-micromachining.jpg',
    copy: 'UV and IR laser processing for ultra-fine, perfectly uniform micro-holes, slots, and dense arrays in thin substrates.'
  }, {
    title: 'Rapid Prototyping',
    img: '../../assets/imagery/rapid-prototyping.jpg',
    copy: 'Fast-turn prototype paths for teams that need DFM feedback and real material parts on compressed timelines.'
  }, {
    title: 'Hybrid CNC + Laser',
    img: '../../assets/imagery/hybrid-stent.jpg',
    copy: 'Structural CNC features and laser-cut detail combined in one managed workflow — as in medical-grade stainless stents.'
  }],
  apps: {
    medical: {
      label: 'Medical Devices',
      summary: 'Implants, surgical instruments, diagnostic cartridges, catheters, and drug-delivery components. ISO 13485-aligned. Biocompatible materials with full traceability.',
      chips: ['±5 µm achievable', 'Ti Gr23 · PEEK · 316L', 'ISO 13485 aligned'],
      mats: ['peek', 'ti-gr23', 'ss316l', 'nitinol']
    },
    microfluidics: {
      label: 'Microfluidics',
      summary: 'Chips, manifolds, diagnostic cartridges, and bonded polymer substrates with fine channel geometry, optical access, and fluid-path precision.',
      chips: ['100 µm channels', 'PMMA · COC · glass', '24 hr prototype response'],
      mats: ['pmma', 'coc', 'borosilicate', 'ptfe']
    },
    aerospace: {
      label: 'Aerospace',
      summary: 'Sensor hardware, lightweight structures, thermal-control components, and precision metallic parts where traceability and setup accuracy matter.',
      chips: ['±10 µm standard', 'Titanium · aluminium · Invar', 'Traceability support'],
      mats: ['ti-gr5', 'aluminium', 'invar', 'ss316l']
    },
    semiconductor: {
      label: 'Semiconductor',
      summary: 'Wafer tooling, chamber hardware, package fixtures, and test supports that need fine features, stable geometry, and clean process fit.',
      chips: ['Sub-50 µm hybrid features', 'Silicon · Cu · Al', 'Fixture + tooling support'],
      mats: ['silicon', 'copper', 'aluminium']
    },
    photonics: {
      label: 'Photonics & Optics',
      summary: 'Lens mounts, apertures, alignment structures, and beam-management hardware where finish, concentricity, and thermal stability matter.',
      chips: ['Optical-grade part fit', 'Invar · Al · glass', 'Fine alignment geometry'],
      mats: ['invar', 'aluminium', 'borosilicate']
    }
  },
  materials: [{
    id: 'peek',
    name: 'PEEK',
    cat: 'Polymers',
    forms: ['Rod', 'Sheet', 'Tube'],
    tags: ['Medical', 'Semiconductor'],
    desc: 'Benchmark high-performance thermoplastic. Biocompatible, autoclavable, chemically inert.'
  }, {
    id: 'pmma',
    name: 'PMMA (Acrylic)',
    cat: 'Polymers',
    forms: ['Sheet', 'Block', 'Film'],
    tags: ['Microfluidics', 'Medical'],
    desc: 'Optically transparent, low-autofluorescence substrate for microfluidic chips.'
  }, {
    id: 'coc',
    name: 'COC (Cyclic Olefin)',
    cat: 'Polymers',
    forms: ['Sheet', 'Film'],
    tags: ['Microfluidics', 'Biotech'],
    desc: 'Ultra-low autofluorescence, high UV transmission, near-zero water absorption.'
  }, {
    id: 'ptfe',
    name: 'PTFE',
    cat: 'Polymers',
    forms: ['Rod', 'Sheet', 'Tube'],
    tags: ['Medical', 'Chemical'],
    desc: 'Widest chemical resistance of any polymer. Zero moisture absorption.'
  }, {
    id: 'ti-gr23',
    name: 'Titanium Grade 23',
    cat: 'Metals',
    forms: ['Rod', 'Sheet', 'Bar', 'Tube'],
    tags: ['Medical', 'Implants'],
    desc: 'Ti-6Al-4V ELI — surgical-grade titanium. ASTM F136 compliant for implants.'
  }, {
    id: 'ti-gr5',
    name: 'Titanium Grade 5',
    cat: 'Metals',
    forms: ['Rod', 'Sheet', 'Bar'],
    tags: ['Aerospace', 'Photonics'],
    desc: 'Ti-6Al-4V — the workhorse aerospace titanium. Highest strength-to-weight.'
  }, {
    id: 'ss316l',
    name: 'Stainless Steel 316L',
    cat: 'Metals',
    forms: ['Rod', 'Sheet', 'Tube', 'Foil'],
    tags: ['Medical', 'Microfluidics'],
    desc: 'Medical-grade low-carbon austenitic stainless. Superior corrosion resistance.'
  }, {
    id: 'nitinol',
    name: 'Nitinol (NiTi)',
    cat: 'Metals',
    forms: ['Wire', 'Sheet', 'Tube'],
    tags: ['Medical', 'Cardiovascular'],
    desc: 'Nickel-titanium shape-memory alloy. Superelasticity for stents and actuators.'
  }, {
    id: 'aluminium',
    name: 'Aluminium 6061',
    cat: 'Metals',
    forms: ['Rod', 'Sheet', 'Bar', 'Tube'],
    tags: ['Aerospace', 'Electronics'],
    desc: 'Aerospace alloy with excellent machinability, corrosion resistance, and strength.'
  }, {
    id: 'copper',
    name: 'Copper (ETP / OFE)',
    cat: 'Metals',
    forms: ['Rod', 'Sheet', 'Foil'],
    tags: ['Electronics', 'RF'],
    desc: 'Highest electrical and thermal conductivity. RF shielding and heat sinks.'
  }, {
    id: 'silicon',
    name: 'Silicon Wafer',
    cat: 'Specialty',
    forms: ['4" Wafer', '6" Wafer'],
    tags: ['Semiconductor', 'MEMS'],
    desc: 'Single-crystal wafers for MEMS, microfluidics, and semiconductor tooling.'
  }, {
    id: 'borosilicate',
    name: 'Borosilicate Glass',
    cat: 'Specialty',
    forms: ['Sheet', 'Wafer'],
    tags: ['Microfluidics', 'Optics'],
    desc: 'Low thermal expansion, optical transparency across UV-VIS.'
  }, {
    id: 'invar',
    name: 'Invar 36',
    cat: 'Specialty',
    forms: ['Rod', 'Sheet', 'Bar'],
    tags: ['Photonics', 'Metrology'],
    desc: 'Near-zero coefficient of thermal expansion for precision optical instruments.'
  }],
  faq: [['What is CNC micromachining?', 'A high-precision subtractive manufacturing process used to create features below 1 mm with tolerances measured in microns. Goodfellow Microfabrication uses it for medical, microfluidic, photonic, semiconductor, and electronics parts that need repeatable dimensional accuracy.'], ['What tolerances can Goodfellow Microfabrication achieve?', 'Goodfellow Microfabrication holds ±10 µm as standard across metals and engineering plastics. Tighter tolerances may be achievable for specific geometries after DFM review, depending on material, feature type, and aspect ratio.'], ['Can Goodfellow Microfabrication machine microfluidic channels in PEEK?', 'Yes. We machine microfluidic features in PEEK and other high-performance polymers for manifolds, diagnostic cartridges, and lab-on-chip systems. Channel geometry, depth, and tolerance stack-up are reviewed during DFM.'], ['How small a feature can Goodfellow Microfabrication machine?', 'CNC features down to roughly 100 µm, with finer detail available through laser or hybrid CNC-laser workflows. Minimum achievable size depends on material, thickness, geometry, and tolerance.'], ['How fast does the team respond to quote requests?', 'Goodfellow Microfabrication typically responds within 24 hours to new quote and drawing submissions. The team then confirms feasibility, the recommended process path, and next quoting steps.'], ['Can I buy material and request machining in one order?', 'Yes. Choose a Goodfellow material, specify form and quantity, and submit it alongside your machining requirement in a single basket. Material supply is coordinated through Goodfellow Materials and machining through Goodfellow Microfabrication.']]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/microfabrication-site/data.js", error: String((e && e.message) || e) }); }

// ui_kits/microfabrication-site/sections1.jsx
try { (() => {
/* global React */
const NS = window.GoodfellowMicrofabricationDesignSystem_aaf2d6;
const {
  Button,
  Eyebrow,
  Badge,
  StatBlock
} = NS;
const PAGE = {
  maxWidth: 'var(--page-max)',
  marginLeft: 'auto',
  marginRight: 'auto'
};
const gridBg = 'linear-gradient(rgba(245,130,31,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(245,130,31,.05) 1px,transparent 1px),linear-gradient(rgba(255,255,255,.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.02) 1px,transparent 1px)';
function Nav({
  basketCount,
  onOpenBasket
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const el = document.querySelector('[data-scroll-root]') || window;
    const onScroll = () => setScrolled((el.scrollTop || window.scrollY) > 8);
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, []);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 200,
      background: '#fff',
      borderBottom: '1px solid var(--gray-100)',
      boxShadow: scrolled ? '0 2px 20px rgba(0,0,0,.12)' : 'none',
      transition: 'box-shadow .2s'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      height: 64,
      padding: '0 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      display: 'flex',
      alignItems: 'center',
      textDecoration: 'none'
    },
    "aria-label": "Goodfellow Microfabrication"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/goodfellow-microfabrication.webp",
    alt: "Goodfellow Microfabrication",
    style: {
      height: 30
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "tel:+14435435737",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--navy)',
      border: '1px solid var(--gray-200)',
      borderRadius: 'var(--radius-pill)',
      padding: '8px 16px',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 8.67 19.79 19.79 0 01.58 5.15 2 2 0 012.54 3h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 10.9a16 16 0 006.29 6.29l1.06-1.06a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 18z"
  })), "+1 443 543 5737"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: onOpenBasket
  }, "Basket"), basketCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -6,
      right: -6,
      background: 'var(--orange)',
      color: '#fff',
      fontSize: 10,
      fontWeight: 800,
      width: 18,
      height: 18,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, basketCount)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    arrow: true
  }, "Get a Quote"))));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'linear-gradient(135deg,#0D1B2A 0%,#15253D 55%,#1D3557 100%)',
      backgroundImage: gridBg,
      backgroundSize: '80px 80px,80px 80px,16px 16px,16px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: '8%',
      top: '-8%',
      width: '48%',
      height: '118%',
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 55% 35%,rgba(29,53,87,.45) 0%,transparent 62%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      position: 'relative',
      zIndex: 1,
      padding: '64px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 620
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "on-dark",
    style: {
      marginBottom: 20
    }
  }, "CNC Micromachining Services"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: '#fff',
      lineHeight: 1.05,
      letterSpacing: '-0.03em',
      margin: '0 0 24px',
      fontSize: 'var(--fs-hero)'
    }
  }, "CNC Micromachining", /*#__PURE__*/React.createElement("br", null), "at ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--orange)'
    }
  }, "\xB110 \xB5m"), /*#__PURE__*/React.createElement("br", null), "Tolerances."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.72,
      color: 'rgba(255,255,255,.6)',
      margin: '0 0 32px',
      maxWidth: 560
    }
  }, "CNC micromachining is a high-precision subtractive manufacturing process that produces features, holes, channels, and threads at the microscopic scale \u2014 with ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'rgba(255,255,255,.9)'
    }
  }, "tolerances held to \xB110 \xB5m"), " and features as small as 100 \xB5m. Goodfellow Microfabrication delivers 4-axis CNC capability combined with laser micromachining for medical, aerospace, photonics, and electronics applications."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 12,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, "Upload Drawing / CAD"), /*#__PURE__*/React.createElement(Button, {
    variant: "dark-outline"
  }, "Request Material + Machining Quote"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    arrow: true,
    style: {
      color: 'rgba(255,255,255,.8)'
    }
  }, "Explore Services")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'rgba(255,255,255,.7)',
      margin: '0 0 6px'
    }
  }, "Upload STEP, STL, or PDF \u2014 our engineers review it for manufacturability."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'rgba(255,255,255,.52)',
      margin: 0
    }
  }, "No redesign required to start \u2014 we'll help optimise your part.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      borderTop: '1px solid rgba(255,255,255,.1)',
      paddingTop: 24
    }
  }, /*#__PURE__*/React.createElement(StatBlock, {
    value: "\xB110\xB5m",
    label: "Tolerance"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "100\xB5m",
    label: "Min Feature",
    divider: true
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "4-Axis",
    label: "CNC Capability",
    divider: true
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "24h",
    label: "Rapid Response",
    divider: true
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: "1982",
    label: "Est.",
    divider: true
  })))));
}
function WhySection() {
  const points = [['Tight tolerance machining', 'achieving micro-scale tolerances for precision components in metals and polymers.'], ['In-house quality control', 'full inspection and validation for consistent CNC machining results.'], ['Scalable manufacturing', 'from prototype to production, maintaining accuracy and repeatability.'], ['Multi-process capability', 'CNC micromachining combined with laser and hybrid fabrication methods.'], ['Engineering support', 'guidance on design, tolerances, and material selection to improve manufacturability.']];
  return /*#__PURE__*/React.createElement("section", {
    id: "why-us",
    style: {
      padding: '64px 24px',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      display: 'grid',
      gap: 32,
      alignItems: 'center',
      gridTemplateColumns: '1.05fr 1fr'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden',
      minHeight: 360,
      background: 'linear-gradient(135deg,#0D1B2A,#1D3557)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/imagery/team-potomac.jpg",
    alt: "The Goodfellow Microfabrication team",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    tone: "navy",
    style: {
      marginBottom: 16,
      letterSpacing: 'var(--ls-eyebrow)'
    }
  }, "Why Goodfellow Microfabrication"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      lineHeight: 1.2,
      letterSpacing: '-0.02em',
      margin: '0 0 16px',
      fontSize: 'var(--fs-h2)'
    }
  }, "Why choose Goodfellow Microfabrication for CNC micromachining"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.75,
      color: 'var(--gray-500)',
      maxWidth: 540,
      margin: '0 0 28px'
    }
  }, "We deliver precision CNC micromachining for micro-scale components \u2014 supporting projects from early prototyping through to full-scale production with engineering-led manufacturing and in-house quality control."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, points.map(([t, c]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--orange)',
      marginTop: 9,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--gray-500)',
      lineHeight: 1.7,
      margin: 0
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--navy-mid)'
    }
  }, t), " \u2014 ", c)))))));
}
function ServicesSection() {
  const {
    services
  } = window.GFM_DATA;
  const {
    Card
  } = NS;
  return /*#__PURE__*/React.createElement("section", {
    id: "services",
    style: {
      padding: '64px 24px',
      background: 'var(--slate-50)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: PAGE
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      flexWrap: 'wrap',
      gap: 16,
      marginBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, "Our Services"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      letterSpacing: '-0.02em',
      margin: '0 0 8px',
      fontSize: 'var(--fs-h2)'
    }
  }, "Explore our precision capabilities"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: 'var(--gray-500)',
      margin: 0,
      maxWidth: 560
    }
  }, "Choose the manufacturing route that fits your geometry, material, and production need.")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    arrow: true
  }, "Explore Applications")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 20
    }
  }, services.map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.title,
    interactive: true,
    accentBar: true,
    padding: "0"
  }, /*#__PURE__*/React.createElement("img", {
    src: s.img,
    alt: s.title,
    style: {
      width: '100%',
      height: 150,
      objectFit: 'cover',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      fontSize: 18,
      margin: '0 0 8px'
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--gray-500)',
      lineHeight: 1.6,
      margin: '0 0 12px'
    }
  }, s.copy), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 800,
      letterSpacing: '.08em',
      textTransform: 'uppercase',
      color: 'var(--orange)'
    }
  }, "Learn more \u2192")))))));
}
Object.assign(window, {
  Nav,
  Hero,
  WhySection,
  ServicesSection,
  GFM_PAGE: PAGE
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/microfabrication-site/sections1.jsx", error: String((e && e.message) || e) }); }

// ui_kits/microfabrication-site/sections2.jsx
try { (() => {
/* global React */
const NS2 = window.GoodfellowMicrofabricationDesignSystem_aaf2d6;
function ApplicationsSection({
  onAddMaterial
}) {
  const {
    Eyebrow,
    Badge,
    Card,
    Tag,
    Button
  } = NS2;
  const {
    apps,
    materials
  } = window.GFM_DATA;
  const keys = Object.keys(apps);
  const [active, setActive] = React.useState(keys[0]);
  const app = apps[active];
  const mats = app.mats.map(id => materials.find(m => m.id === id)).filter(Boolean);
  const PAGE = window.GFM_PAGE;
  return /*#__PURE__*/React.createElement("section", {
    id: "applications",
    style: {
      padding: '64px 24px',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: PAGE
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, "Applications"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      letterSpacing: '-0.02em',
      margin: '0 0 24px',
      fontSize: 'var(--fs-h2)'
    }
  }, "Industries we machine for"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 4,
      borderBottom: '1px solid var(--gray-200)',
      marginBottom: 28
    }
  }, keys.map(k => {
    const on = k === active;
    return /*#__PURE__*/React.createElement("button", {
      key: k,
      onClick: () => setActive(k),
      style: {
        border: 'none',
        background: on ? '#FEF0E3' : 'transparent',
        cursor: 'pointer',
        borderBottom: `3px solid ${on ? 'var(--orange)' : 'transparent'}`,
        padding: '12px 18px',
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        fontWeight: on ? 800 : 600,
        color: on ? 'var(--orange)' : 'var(--gray-500)',
        transition: 'all .2s'
      }
    }, apps[k].label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) 300px',
      gap: 24,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.7,
      color: 'var(--gray-600)',
      margin: '0 0 16px'
    }
  }, app.summary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      marginBottom: 24
    }
  }, app.chips.map((c, i) => /*#__PURE__*/React.createElement(Badge, {
    key: c,
    tone: "rose",
    solid: i === 0
  }, c))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--gray-400)',
      marginBottom: 12
    }
  }, "Recommended materials"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,1fr)',
      gap: 12
    }
  }, mats.map(m => /*#__PURE__*/React.createElement(Card, {
    key: m.id,
    padding: "16px",
    style: {
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0 1px 2px rgba(15,23,42,.04)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 8,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      color: 'var(--navy-mid)',
      fontSize: 14
    }
  }, m.name), /*#__PURE__*/React.createElement(Tag, null, m.cat)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--gray-500)',
      lineHeight: 1.5,
      margin: '0 0 12px',
      flex: 1
    }
  }, m.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, m.forms.slice(0, 2).map(f => /*#__PURE__*/React.createElement(Tag, {
    key: f
  }, f))), /*#__PURE__*/React.createElement("button", {
    onClick: () => onAddMaterial(m),
    style: {
      border: '1px solid var(--orange)',
      background: '#fff',
      color: 'var(--orange)',
      borderRadius: 'var(--radius-pill)',
      padding: '4px 12px',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '.08em',
      textTransform: 'uppercase',
      cursor: 'pointer'
    }
  }, "+ Add")))))), /*#__PURE__*/React.createElement(Card, {
    tone: "quiet",
    padding: "18px",
    style: {
      position: 'sticky',
      top: 88
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      fontSize: 15,
      marginBottom: 12
    }
  }, "Buy material + request machining"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: '0 0 16px',
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, ['Select a Goodfellow material', 'Specify form, quantity & tolerance', 'Submit one combined request'].map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    style: {
      position: 'relative',
      paddingLeft: 14,
      fontSize: 13,
      lineHeight: 1.5,
      color: 'var(--gray-500)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 8,
      width: 5,
      height: 5,
      borderRadius: '50%',
      background: 'var(--orange)'
    }
  }), t))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    fullWidth: true,
    arrow: true
  }, "Request Quote")))));
}
function WorkflowSection() {
  const {
    Eyebrow
  } = NS2;
  const PAGE = window.GFM_PAGE;
  const steps = [['Upload', 'Send STEP, STL, IGES, PDF, or DXF — no redesign needed to start.'], ['DFM review', 'Engineers review geometry, material, and tolerance for manufacturability.'], ['Quote', 'We confirm feasibility, process path, and pricing within 24 hours.'], ['Machine', 'CNC, laser, or hybrid production with in-house quality control.'], ['Deliver', 'Inspected parts with traceability and first-article reporting on request.']];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '56px 24px',
      background: 'var(--slate-50)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    align: "center",
    style: {
      marginBottom: 12,
      justifyContent: 'center'
    }
  }, "How it works"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      letterSpacing: '-0.025em',
      margin: '0 auto 36px',
      fontSize: 'var(--fs-h2)',
      maxWidth: 760
    }
  }, "From CAD to inspected parts in one managed workflow"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(5,1fr)',
      gap: 18,
      position: 'relative'
    }
  }, steps.map(([t, c], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 50,
      height: 50,
      borderRadius: '50%',
      background: '#fff',
      border: '2px solid rgba(245,130,31,.38)',
      boxShadow: '0 8px 24px rgba(245,130,31,.08)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 18,
      color: 'var(--navy-mid)',
      marginBottom: 12
    }
  }, i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      minHeight: 150,
      border: '1px solid var(--gray-200)',
      borderRadius: 'var(--radius-card)',
      background: '#fff',
      boxShadow: 'var(--shadow-card)',
      padding: '20px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 800,
      letterSpacing: '.22em',
      textTransform: 'uppercase',
      color: 'var(--gray-400)',
      marginBottom: 14
    }
  }, "Step ", i + 1), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      fontSize: 15,
      marginBottom: 10
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      lineHeight: 1.6,
      color: 'var(--gray-500)',
      margin: 0
    }
  }, c)))))));
}
Object.assign(window, {
  ApplicationsSection,
  WorkflowSection
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/microfabrication-site/sections2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/microfabrication-site/sections3.jsx
try { (() => {
/* global React */
const NS3 = window.GoodfellowMicrofabricationDesignSystem_aaf2d6;
function QuoteSection({
  basketCount
}) {
  const {
    Eyebrow,
    Input,
    Textarea,
    Select,
    FileUpload,
    Button
  } = NS3;
  const PAGE = window.GFM_PAGE;
  return /*#__PURE__*/React.createElement("section", {
    id: "quote",
    style: {
      padding: '76px 24px 100px',
      background: 'var(--slate-50)',
      borderTop: '1px solid #EEF2F7'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 860,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      maxWidth: 760,
      margin: '0 auto 34px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    align: "center",
    style: {
      justifyContent: 'center',
      marginBottom: 12
    }
  }, "Request a Quote"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      lineHeight: 1.08,
      letterSpacing: '-0.03em',
      margin: '0 0 16px',
      fontSize: 'var(--fs-display)'
    }
  }, "Material + machining, one request"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.65,
      color: 'var(--gray-600)',
      margin: 0
    }
  }, "Share your CAD files and tolerance requirements. Engineers review every design for manufacturability and respond within one business day.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1px solid var(--gray-200)',
      borderRadius: 18,
      boxShadow: '0 22px 60px rgba(15,42,68,.08)',
      padding: 28
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 14,
      fontWeight: 800,
      color: 'var(--navy-mid)',
      margin: '0 0 20px'
    }
  }, "Step 1 \u2014 Tell us about your part"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Your name",
    required: true,
    placeholder: "Dr. Jane Smith"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Organisation",
    placeholder: "University / Company"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    type: "email",
    required: true,
    placeholder: "j.smith@example.com"
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Part description and requirements",
    required: true,
    rows: 3,
    placeholder: "e.g. Titanium implant, 4 machined faces, \xB18 \xB5m on mating surfaces, 50 parts, first-article report required"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Tolerance required",
    placeholder: "Select\u2026",
    options: ['±10 µm (standard)', '±5 µm (precision)', 'Sub-5 µm (discuss)']
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Quantity (parts)",
    type: "number",
    defaultValue: 1,
    min: 1
  })), /*#__PURE__*/React.createElement(FileUpload, {
    id: "quote-cad"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      fontSize: 12,
      color: 'var(--gray-500)',
      border: '1px solid rgba(245,130,31,.2)',
      background: 'rgba(245,130,31,.05)',
      borderRadius: 6,
      padding: '8px 12px',
      lineHeight: 1.5
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--orange)'
    }
  }, "How this works:"), " Material is supplied by Goodfellow Materials. Machining is delivered by Goodfellow Microfabrication. ", basketCount > 0 ? `${basketCount} basket material(s) will be included.` : 'Optional testing & validation via Suisse TP.'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 18,
      marginTop: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--gray-500)'
    }
  }, "No commitment. Our engineers respond within 24 hours."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    arrow: true
  }, "Request Material + Machining Quote")))));
}
function FaqSection() {
  const {
    Eyebrow,
    FaqItem,
    Button
  } = NS3;
  const PAGE = window.GFM_PAGE;
  const {
    faq
  } = window.GFM_DATA;
  const [open, setOpen] = React.useState(0);
  return /*#__PURE__*/React.createElement("section", {
    id: "faq",
    style: {
      padding: '64px 24px',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      display: 'grid',
      gridTemplateColumns: '340px 1fr',
      gap: 32,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 88
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, "FAQ"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: 'var(--navy-mid)',
      lineHeight: 1.2,
      letterSpacing: '-0.02em',
      margin: '0 0 12px',
      fontSize: 'var(--fs-title)'
    }
  }, "Common questions"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--gray-500)',
      lineHeight: 1.6,
      margin: '0 0 20px'
    }
  }, "Direct answers to the engineering, materials, and process questions buyers most often ask when evaluating a microfabrication partner."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "Ask a Technical Question")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--gray-100)'
    }
  }, faq.map(([q, a], i) => /*#__PURE__*/React.createElement(FaqItem, {
    key: i,
    question: q,
    open: open === i,
    onToggle: n => setOpen(n ? i : -1),
    last: i === faq.length - 1
  }, a)))));
}
function CtaSection() {
  const {
    Button
  } = NS3;
  const PAGE = window.GFM_PAGE;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      padding: '80px 24px',
      borderTop: '1px solid rgba(255,255,255,.1)',
      background: 'linear-gradient(135deg,#16253D 0%,#1B2E4A 52%,#213754 100%)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      background: 'radial-gradient(circle at 50% 14%,rgba(245,130,31,.10) 0%,transparent 18%),radial-gradient(circle at 50% 50%,rgba(255,255,255,.04) 0%,transparent 36%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      position: 'relative',
      zIndex: 1,
      textAlign: 'center',
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 1,
      background: 'rgba(245,130,31,.9)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '.22em',
      textTransform: 'uppercase',
      color: 'var(--orange)'
    }
  }, "Get Started Today"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 1,
      background: 'rgba(245,130,31,.9)'
    }
  })), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      color: '#fff',
      lineHeight: 1.02,
      letterSpacing: '-0.035em',
      margin: '0 0 20px',
      fontSize: 'var(--fs-display)'
    }
  }, "Ready to machine", /*#__PURE__*/React.createElement("br", null), "at the micron scale?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      color: 'rgba(255,255,255,.72)',
      lineHeight: 1.7,
      maxWidth: 640,
      margin: '0 auto 32px'
    }
  }, "Share your CAD files and tolerance requirements. Engineers review every design for manufacturability and respond within one business day."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, "Request a Quote"), /*#__PURE__*/React.createElement(Button, {
    variant: "dark-outline"
  }, "Upload CAD"))));
}
function Footer() {
  const PAGE = window.GFM_PAGE;
  const cols = [['Services', ['CNC Micromachining', 'Laser Micromachining', 'Rapid Prototyping', 'Hybrid Fabrication']], ['Applications', ['Medical Devices', 'Microfluidics', 'Aerospace', 'Semiconductor']], ['Goodfellow Group', ['Advanced Materials', 'Microfabrication', 'Reference Materials', 'Testing & Analysis']]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: '#0D1B2A',
      color: '#fff',
      padding: '48px 24px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr 1fr',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/goodfellow-microfabrication-large.png",
    alt: "Goodfellow Microfabrication",
    style: {
      height: 38,
      marginBottom: 16,
      filter: 'brightness(0) invert(1)',
      opacity: 0.92
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      lineHeight: 1.7,
      color: 'rgba(255,255,255,.55)',
      margin: '0 0 16px',
      maxWidth: 320
    }
  }, "Precision CNC, laser, and hybrid micromachining for regulated programs. Material supply through Goodfellow Materials; validation via Suisse TP."), /*#__PURE__*/React.createElement("a", {
    href: "tel:+14435435737",
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--orange)',
      textDecoration: 'none'
    }
  }, "+1 443 543 5737")), cols.map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 800,
      letterSpacing: '.16em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,.4)',
      marginBottom: 14
    }
  }, h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, items.map(it => /*#__PURE__*/React.createElement("li", {
    key: it
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 13,
      color: 'rgba(255,255,255,.7)',
      textDecoration: 'none'
    }
  }, it))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...PAGE,
      borderTop: '1px solid rgba(255,255,255,.1)',
      marginTop: 36,
      paddingTop: 20,
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'rgba(255,255,255,.4)'
    }
  }, "\xA9 Goodfellow Microfabrication. Est. 1982 \xB7 Formerly Potomac Photonics."), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'rgba(255,255,255,.4)'
    }
  }, "ISO 13485 aligned \xB7 \xB110 \xB5m standard \xB7 No MOQ")));
}
Object.assign(window, {
  QuoteSection,
  FaqSection,
  CtaSection,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/microfabrication-site/sections3.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.FaqItem = __ds_scope.FaqItem;

__ds_ns.FileUpload = __ds_scope.FileUpload;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
