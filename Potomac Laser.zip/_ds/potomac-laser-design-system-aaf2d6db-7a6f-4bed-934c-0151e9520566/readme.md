# Goodfellow Microfabrication — Design System

A brand & UI design system for **Goodfellow Microfabrication**, the precision micro-manufacturing arm of the Goodfellow Group (the business formerly known as **Potomac Photonics / Potomac Laser**, Baltimore MD — the team still wears "POTOMAC" lab coats). Goodfellow Microfabrication delivers CNC micromachining, laser micromachining, hybrid fabrication, microfluidics, and micro-assembly for medical, aerospace, microfluidic, semiconductor, and photonics programs.

It sits alongside three sibling Goodfellow divisions that share the multicolored "G" mark:
**Advanced Materials**, **Reference Materials**, and **Testing & Analysis** (plus the partner brand **Suisse TP** for validation/certification). Material supply is coordinated through **Goodfellow Materials** (170,000+ grades); machining is delivered by Goodfellow Microfabrication.

## Sources
This system was reverse-engineered from one source asset:
- `uploads/CNC micromachining Goodfellow Microfabrication - standalone final.html` — a standalone, single-page marketing/quote page for CNC Micromachining Services. It uses Tailwind (CDN) with a custom theme, inline `<style>` blocks, and base64-embedded imagery. Canonical URL referenced in the file: `https://www.goodfellow.com/usa/services/microfabrication`.

All tokens, copy patterns, components, and the UI kit below are derived from that file. There was no Figma or repo — if you have the production codebase or brand guidelines, share them and this system can be tightened.

---

## CONTENT FUNDAMENTALS

**Voice.** Engineering-led, precise, confident, never hype-y. The brand speaks as a capable manufacturing partner that reviews your design before quoting. Specs do the persuading.

- **Person.** The company refers to itself in the **third person by full name** in authoritative/SEO contexts ("Goodfellow Microfabrication holds ±10 µm as standard…", "the team confirms feasibility") and switches to **"we / our engineers"** in CTAs and reassurance copy ("our engineers respond within 24 hours", "we'll help optimise your part"). The reader is **"you / your part / your CAD"**.
- **Spelling.** International / British English: *optimise, aluminium, fibre.* Keep it.
- **Units.** Microns are written **µm** (with the µ glyph), always spaced: "±10 µm", "100 µm channels", "sub-50 µm". This is the single most repeated motif in the copy.
- **Numbers as proof.** Hard, specific figures everywhere: `±10 µm` tolerance, `100 µm` min feature, `4-axis` CNC, `24h` response, `Est. 1982`, `170,000+` grades. Stats are stacked in divider-separated rows.
- **Casing.** Sentence case for headings and body. **UPPERCASE** is reserved for eyebrows/kickers, button labels, stat captions, and field labels — always with wide letter-spacing.
- **Trademarks.** Material names carry their marks: *Kapton®*, *PEEK*, *Nitinol (NiTi)*, *Invar 36*, *Ti-6Al-4V ELI*.
- **Standards name-drops** signal regulated-industry credibility: *ISO 13485 aligned, ASTM F136, DFM review, first-article report, traceability.*
- **Emoji.** Effectively none. (One stray 🧪 in an empty-basket state in the source — do **not** propagate it. Treat the brand as emoji-free.) Iconography is line SVG, not emoji.
- **Punctuation.** Em-dashes for asides, "→" arrows on links and buttons ("Learn more →", "Request a Quote →"), mid-dots "·" to separate inline proof chips ("No commitment · 24h response").

**Copy examples (verbatim from source):**
- Eyebrow: `CNC MICROMACHINING SERVICES`
- H1: "CNC Micromachining at **±10 µm** Tolerances."
- Lead: "CNC micromachining is a high-precision subtractive manufacturing process that produces features, holes, channels, and threads at the microscopic scale…"
- Reassurance pair (recurring): "Upload STEP, STL, or PDF — our engineers review it for manufacturability." / "No redesign required to start — we'll help optimise your part."
- Microcopy under CTAs: "No commitment. Our engineers respond within 24 hours."
- Section kickers: `WHY GOODFELLOW MICROFABRICATION`, `OUR SERVICES`, `GET STARTED TODAY`, `FAQ`.

---

## VISUAL FOUNDATIONS

**Color.** A two-color brand: **orange `#F5821F`** (the single accent — CTAs, eyebrow lines, stat numbers, link arrows, focus rings) against **navy `#15253D` / `#1D3557`** (headings, dark surfaces). Neutrals are cool grays (`#6B7280` body, `#E5E7EB` borders, `#F9FAFB`/`#F8FAFC` washes). A **rose `#E74861`** appears only as secondary "proof chips," and a **teal `#6BD0E3`** tags technical labels on dark panels — both are rare. The multicolored confetti "G" logo is the one place many colors coexist; the UI itself stays disciplined orange-on-navy-on-gray.

**Type.** Display headings in **Nunito 800 (extrabold)** with tight tracking (`-0.03em`); body and UI in **Nunito Sans** (400/600/700). The recurring **"eyebrow / kicker"** — an 11px uppercase, `0.18em`-tracked orange label, often preceded by a 32×2px orange rule — opens nearly every section. Display sizes are fluid (`clamp()`), bottoming out large; body copy is `15px` at `1.7` line-height, secondary copy `13–14px`.

**Spacing & layout.** Centered `1260px` max-width pages with `24px` gutters; centered prose capped near `760px`. Generous section padding (`64–80px` vertical). Multi-column responsive grids (services 3-up, materials up to 3-up, workflow 5-step timeline). Consistent `gap`-based layout.

**Backgrounds.** Three signature treatments: (1) **navy gradient panels** (`135deg, #16253D → #1B2E4A → #213754`) for hero/CTA/dark feature blocks; (2) **engineering grid overlays** — faint 16px + 64–80px line grids in white/orange at very low opacity, sometimes with radial orange/blue **glow** spots; (3) **light washes** (`#F8FAFC`, `#F9FAFB`) to separate sections on white. No photographic full-bleed heroes — imagery lives inside cards and panels. No noise/grain.

**Imagery.** Real process & product photography: warm **brass and steel** micro-parts (milled blocks, micro gears, laser-cut Nitinol stents), laser-drilled glass with rainbow diffraction, CAD-overlay shots. Warm metallic subjects shot on cool dark backgrounds — the warm/cool contrast mirrors the orange/navy palette. Team photo is candid, lab-coated, human.

**Corner radii.** `9999px` pills for every button/chip/tag; `8px` for standard cards; `12px` for inputs and small step cards; `18–20px` for feature cards and dark panels. Nothing is fully square.

**Cards.** White, `1px #E5E7EB` border, `8px` radius, resting shadow `0 2px 8px rgba(0,0,0,.07)`. Interactive material cards use a `1.5px` border that turns orange on hover with a `translateY(-2px)` lift and orange-tinted shadow; selected state fills `#FEF9F5`, keeps the orange border, and drops a small orange ✓ badge top-right. Some cards carry an `::after` orange underline bar that scales in from the left on hover (`card-accent`).

**Borders & dividers.** Hairline `1px #E5E7EB` everywhere; on dark panels, `rgba(255,255,255,.08–.12)`. Stat rows use thin vertical dividers between items.

**Shadows.** Restrained and layered: card `0 2px 8px rgba(0,0,0,.07)`, raised `0 10px 36px rgba(0,0,0,.12)`, navy-tinted hover lift `0 10px 24px rgba(15,42,68,.08)`. The **orange glow** `0 8px 24px rgba(245,130,31,.3)` is reserved exclusively for primary CTAs. Dark feature panels carry a deep `0 22px 58px rgba(15,42,68,.18)`.

**Buttons.**
- *Primary* — pill, orange fill, white **uppercase bold** label, wide tracking, orange glow shadow; hover → `#D96E10` + `translateY(-1px)`.
- *Secondary* — pill, white fill, navy text, `1–2px` navy/gray border; hover fills navy or darkens border.
- *Ghost / link* — uppercase tracked label, often with a `→`; hover shifts to orange.

**Hover states.** Buttons lift `-1px` and darken; cards lift `-1px/-2px` with a stronger navy-tinted shadow and (for material cards) an orange border; links shift to orange. App tabs gain an orange bottom-border + `#FEF0E3` wash.

**Press / focus.** Tap highlight `rgba(245,130,31,.18)`. Focus-visible draws a `3px rgba(245,130,31,.35)` outline with `3px` offset; form fields get an orange border + `0 0 0 3px rgba(245,130,31,.12)` ring.

**Animation.** A single signature easing — `cubic-bezier(.25,.46,.45,.94)`. Patterns: scroll **reveal** (fade + 18px rise, staggered `80ms` delays `d1…d5`), hero **fade-up** entrance, panels/drawers **slide** (`.35s`), FAQ **max-height** accordion, and a subtle **pulse** dot for live/social-proof. Fades and rises, never bounces; tasteful and short. Respect `prefers-reduced-motion`.

**Transparency & blur.** Used lightly — white-alpha surfaces and borders on dark panels, low-opacity grid/glow overlays. No heavy glassmorphism/backdrop-blur.

---

## ICONOGRAPHY

- **System:** Inline **stroke SVG** icons in the source, drawn at `stroke-width:2–2.5`, `viewBox 0 0 24 24`, `fill:none stroke:currentColor` — i.e. **Feather / Lucide–style line icons**. They appear in the phone link (handset), workflow steps, secure-form padlock, and proof rows, sized `13–26px`, inheriting color (orange on light accents, `#6A86C8` muted blue on proof rows, white on dark).
- **Recommendation:** Use **[Lucide](https://lucide.dev)** as the icon set — it matches the stroke weight and rounded-join style exactly. Link from CDN (`https://unpkg.com/lucide@latest`) or inline individual paths. This is a **substitution** for the hand-authored SVGs in the source (which were one-off paths, not a named set) — flagged for the user to confirm.
- **No icon font** is used. **No emoji** (treat as forbidden). **No unicode glyph icons** except the functional `→` arrow on links/buttons, `✓` on selected cards, `×` on close buttons, and `+` (rotates to ×) on FAQ toggles.
- **Logos:** the multicolored confetti "G" lockup in four divisional variants — see `assets/logos/`.

---

## INDEX / MANIFEST

**Root**
- `styles.css` — global entry (import this). `@import`s all tokens.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill front matter for portable use.

**`tokens/`** — CSS custom properties
- `fonts.css` — Nunito + Nunito Sans (Google Fonts)
- `colors.css` — brand, neutrals, semantic aliases
- `typography.css` — families, sizes, weights, tracking
- `spacing.css` — spacing, radii, borders, shadows, layout, motion

**`assets/`**
- `logos/` — Microfabrication (webp + png), Advanced Materials, Reference Materials, Testing & Analysis
- `imagery/` — process & product photos (cnc, laser, rapid-proto, hybrid stent, micro-assembly), team photo

**`components/core/`** — reusable primitives (React): `Button`, `Eyebrow`, `Badge`, `Tag`, `StatBlock`, `Card`, `Input`, `Textarea`, `Select`, `FileUpload`, `FaqItem`. See each `*.prompt.md`.

**`ui_kits/microfabrication-site/`** — interactive recreation of the CNC Micromachining marketing/quote page (hero, why, services, applications, workflow, quote, FAQ, CTA).

**`templates/microfabrication-landing/`** — a copyable starting-point template (`MicrofabricationLanding.dc.html`) composing DS components: navy hero + stat strip, services row, CTA band.

**`guidelines/`** — foundation specimen cards (Type, Colors, Spacing, Brand) rendered in the Design System tab.

> The namespace for `window.<Namespace>.<Component>` in card/kit HTML is reported by `check_design_system`.
