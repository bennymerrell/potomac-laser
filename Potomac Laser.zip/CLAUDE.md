# Project: Potomac Laser service pages

## Standing instructions
- Service pages are built from the CNC Micromachining template (`CNC Micromachining.html`), but **every section's text must be rewritten to fit that page's specific topic** — not left with inherited copy from another service. This includes hidden/interactive sections that are easy to miss: the **"Select your application" explorer (`APPS` JS object: summaries, chips, materials)**, testimonials, quote-form placeholders, capability spec rows, process-selection cards, "How it works" steps, FAQ (both visible and JSON-LD schema), and all `<head>` metadata/schema.
- **Never overstate service claims.** All copy — especially FAQ answers, stats, tolerances, turnaround times, and materials — must be grounded strictly in the corresponding page on potomac-laser.com. Do not invent figures or capabilities beyond what that source page states.
- Keep the shared template structure and styling intact; only the topic-specific text changes.
