# Project: Potomac Laser service pages

## Standing instructions
- Service pages are built from the CNC Micromachining template (`Services - CNC Micromachining.html`), but **every section's text must be rewritten to fit that page's specific topic** — not left with inherited copy from another service. This includes hidden/interactive sections that are easy to miss: the **"Select your application" explorer (`APPS` JS object: summaries, chips, materials)**, testimonials, quote-form placeholders, capability spec rows, process-selection cards, "How it works" steps, FAQ (both visible and JSON-LD schema), and all `<head>` metadata/schema.
- **Never overstate service claims.** All copy — especially FAQ answers, stats, tolerances, turnaround times, and materials — must be grounded strictly in the corresponding page on potomac-laser.com. Do not invent figures or capabilities beyond what that source page states.
- Keep the shared template structure and styling intact; only the topic-specific text changes.
- **All visible copy must live in the HTML, never in JavaScript.** Every page must be editable in place: click Edit, click any text, type. That means no copy inside JS data objects, template literals, `innerHTML =`, or `textContent =`.
  - Repeated/tabbed content (application panels, method panels, material drawers, FAQ lists, gallery cards, filter chips) is written out as **static markup for every state**, each state marked with a data attribute (e.g. `data-app-panel`, `data-mat-panel`, `data-method-panel`, `data-gal-card`) and `hidden` on the inactive ones.
  - JavaScript may only **show/hide, filter, or toggle classes** on that markup — it must never build or rewrite text.
  - Two-state copy (idle vs. submitted, current vs. alternate section heading) is two static sibling elements toggled with `hidden` (`data-note-state`, `data-btn-state`, `.appx-orig` / `.appx-alt`), not a string swap.
  - Only genuinely runtime values — counts, indices ("3 / 12"), and user-entered basket items — may be written by JS.
